# Configuration settings for DAX V2 Backend
#
# Semua pengaturan di file ini bisa di-override lewat file .env
# (contoh lengkap ada di Backend/.env.example). Yang paling penting untuk
# diisi: GROQ_API_KEY (kunci AI) dan NEWS_API_KEY (kunci berita).

from pydantic_settings import BaseSettings
from typing import Optional
import os
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    # Application
    APP_NAME: str = "DAX V2 AI Trading Backend"
    APP_VERSION: str = "2.0.0"
    DEBUG: bool = False
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # API Keys
    GROQ_API_KEY: str = ""
    NEWS_API_KEY: str = ""
    
    # Groq Settings
    GROQ_MODEL: str = "openai/gpt-oss-120b"
    GROQ_MAX_TOKENS: int = 1000
    GROQ_TEMPERATURE: float = 0.3
    
    # News API Settings
    NEWS_API_ENABLED: bool = True
    NEWS_FETCH_INTERVAL: int = 300
    
    # Trading Defaults
    DEFAULT_SYMBOL: str = "EURUSD"
    MAX_RISK_PER_TRADE: float = 0.02
    MAX_DAILY_LOSS: float = 0.10
    RISK_REWARD_RATIO: float = 2.0
    
    # Security
    API_SECRET_KEY: str = "your-secret-key-change-in-production"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
