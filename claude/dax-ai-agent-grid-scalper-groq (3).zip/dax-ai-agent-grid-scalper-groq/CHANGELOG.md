# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.0] - Groq Edition (remake)

### Diubah (Changed)
- **Penyedia AI diganti ke Groq**: Semua pemanggilan analisa AI (di `GroqAI.mqh`,
  `groq_service.py`, dan modul LLM pada proyek `legacy/`) sekarang memakai
  [Groq API](https://console.groq.com) dengan model `openai/gpt-oss-120b`,
  menggantikan DeepSeek. Endpoint: `https://api.groq.com/openai/v1/chat/completions`.
- **File & variabel dinamai ulang** agar jelas: `DeepSeekAI.mqh` → `GroqAI.mqh`,
  `DeepSeekNewsGridScalper_V2.mq5` → `GroqNewsGridScalper.mq5`,
  `deepseek_service.py` → `groq_service.py`, `DEEPSEEK_API_KEY` → `GROQ_API_KEY`, dst.
- **Dokumentasi ditulis ulang dalam Bahasa Indonesia** (README, QUICKSTART,
  README_FastAPI) supaya lebih mudah dipahami, tanpa mengubah fungsi apa pun.

### Tidak berubah (Unchanged)
- Seluruh logika grid trading, circuit breaker, filter berita, dan perhitungan
  risiko **identik** dengan versi sebelumnya — hanya penyedia AI yang diganti.

## [2.0.0] - 2026-08-25

### Added
- **Groq AI integration**: LLM-powered market analysis with BUY/SELL/HOLD signal generation, confidence scoring, and 0-100% dynamic risk assessment (`GroqAI.mqh`, `groq_service.py`)
- **NewsAPI intelligence**: Real-time forex news sentiment scoring, high-impact event detection, and automatic pre-news caution mode (30 min before events, -50% position size, +20% spread tightening) (`NewsAPI.mqh`, `news_service.py`)
- **Grid trading engine**: Breakout-based grid with configurable distance/orders, trailing stops, and break-even protection
- **FastAPI backend**: Python 3.11 REST API with 15+ endpoints covering trading signals, risk assessment, position sizing, dynamic SL/TP, circuit breakers, and news queries (`/docs` Swagger UI included)
- **Circuit breaker risk management**: Daily loss limit (default 10%), max drawdown halt (default 15%), AI-adjusted limits when risk score > 70%
- **EA variants**: `GroqNewsGridScalper` (flagship standalone), `EAFastConnector` (FastAPI mode), `DAX_M5_Standalone` (M5 scalping), `DAX_FibATR_Trend` (Fibonacci ATR trend), `Fibonation_Grid` (Fibonacci-spaced grid)
- **Docker support**: Production-ready Dockerfile + docker-compose.yml with health checks
- **On-chart dashboard**: Real-time engine status, balance/equity, AI risk/confidence/signal, news status, RSI/ATR/EMA indicators
- **SEO landing page** with FAQ, structured data (SoftwareApplication, FAQPage, HowTo schemas), Open Graph, and `llms.txt` / `llms-full.txt` for LLM discoverability
- **CI pipeline**: GitHub Actions with Python lint (ruff), Docker build test, MQL5 source validation

### Risk Management Details
- Micro account support: auto-reduced SL to 250 pts for small balances, 25% DD limit under minimum balance threshold
- Drawdown breaker: peak-equity tracking, daily reset, halts new trading instead of force-closing positions
- Grid overtrading fix: 30-minute cooldown between grid activations matching Python backtest logic

### Fixed
- Fibonacci array out-of-range error (size 6 → 7)
- Fibonacci EA optimized SL/TP calculation (atr*0.9*8, 1x/2x spacing)
- Grid overtrading via time-based cooldown

## [1.0.0] - Initial Development

### Added
- Basic grid trading engine
- Simple risk controls
- Standard trailing stops

[2.0.0]: https://github.com/foeed/dax-ai-agent-grid-scalper/releases/tag/v2.0.0
