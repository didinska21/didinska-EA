# DAX V2: Arsitektur FastAPI + MQ5 (Groq Edition)

## Sistem Grid Trading Bertenaga AI

Sistem trading siap-produksi yang menggabungkan backend FastAPI dengan Expert Advisor
MetaTrader 5.

---

## 🏗️ Arsitektur

```
┌─────────────────────┐         ┌─────────────────────────┐
│   MetaTrader 5      │  HTTP   │    Backend FastAPI       │
│   (EA MQ5)          │◄───────►│    (Python 3.11)        │
│                     │         │                         │
│  - Grid Trading     │         │  - Groq AI               │
│  - Eksekusi Order   │         │  - News API               │
│  - Cek Risiko       │         │  - Manajemen Risiko        │
│  - Dashboard        │         │  - Ukuran Posisi           │
└─────────────────────┘         └─────────────────────────┘
```

---

## 📁 Struktur Proyek

```
DAX_V2/
├── Backend/                    # Backend FastAPI
│   ├── app/
│   │   ├── main.py            # Aplikasi FastAPI
│   │   ├── core/
│   │   │   ├── config.py      # Pengaturan
│   │   │   └── database.py    # Manajer database
│   │   ├── routers/
│   │   │   ├── trading.py     # Endpoint trading
│   │   │   ├── analysis.py    # Analisa AI
│   │   │   ├── news.py        # Endpoint berita
│   │   │   └── risk.py        # Manajemen risiko
│   │   ├── services/
│   │   │   ├── groq_service.py      # Groq AI
│   │   │   ├── news_service.py      # News API
│   │   │   ├── risk_service.py      # Perhitungan risiko
│   │   │   └── scheduler.py         # Tugas background
│   │   └── models/
│   │       └── schemas.py     # Model Pydantic
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── requirements.txt
│   └── start.bat
│
├── MQ5_FastAPI/               # EA MetaTrader 5
│   └── EAFastConnector.mq5   # EA utama mode FastAPI
│
├── Include/                   # Modul MQ5 mandiri
│   ├── NewsAPI.mqh
│   └── GroqAI.mqh
│
└── README_FastAPI.md          # File ini
```

---

## 🚀 Mulai Cepat

### Opsi 1: Docker (Disarankan)

```bash
# 1. Masuk ke DAX_V2/Backend
cd DAX_V2/Backend

# 2. Buat file .env
copy .env.example .env

# 3. Edit .env, isi API key kamu
notepad .env

# 4. Jalankan dengan Docker Compose
docker-compose up -d

# 5. Cek status
docker-compose ps
```

### Opsi 2: Python Lokal

```bash
# 1. Masuk ke folder backend
cd DAX_V2/Backend

# 2. Jalankan skrip start
start.bat
```

### Opsi 3: Setup Manual

```bash
# 1. Buat virtual environment
python -m venv venv
venv\Scripts\activate  # Windows
# source venv/bin/activate  # Linux/Mac

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set environment variables
set GROQ_API_KEY=your_key
set NEWS_API_KEY=your_key

# 4. Jalankan server
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

---

## 🔑 Setup API Key

### Groq AI
1. Buka https://console.groq.com/keys
2. Buat akun
3. Buat API key baru
4. Salin API key tersebut
5. Model yang dipakai: `openai/gpt-oss-120b`

### NewsAPI (Gratis)
1. Buka https://newsapi.org/register
2. Daftar
3. Salin API key
4. Tier gratis: 100 request/hari

---

## 📡 Daftar Endpoint API

### Trading
| Method | Endpoint | Penjelasan |
|--------|----------|-------------|
| POST | `/api/v1/trading/signal` | Ambil sinyal trading AI (instan) |
| POST | `/api/v1/trading/analyze` | Analisa pasar lengkap |
| POST | `/api/v1/trading/positions/update` | Update posisi |
| GET | `/api/v1/trading/dashboard` | Data dashboard |

### Manajemen Risiko
| Method | Endpoint | Penjelasan |
|--------|----------|-------------|
| POST | `/api/v1/risk/assess` | Penilaian risiko |
| POST | `/api/v1/risk/position-size` | Ukuran posisi |
| POST | `/api/v1/risk/dynamic-sl` | Hitung stop loss dinamis |
| POST | `/api/v1/risk/dynamic-tp` | Hitung take profit |
| POST | `/api/v1/risk/circuit-breakers` | Cek rem darurat |

### Berita
| Method | Endpoint | Penjelasan |
|--------|----------|-------------|
| GET | `/api/v1/news/{symbol}` | Ambil berita forex |
| GET | `/api/v1/news/{symbol}/sentiment` | Skor sentimen |
| GET | `/api/v1/news/{symbol}/high-impact` | Cek berita berdampak tinggi |

### Sistem
| Method | Endpoint | Penjelasan |
|--------|----------|-------------|
| GET | `/` | Endpoint root |
| GET | `/health` | Cek kesehatan server |
| POST | `/api/v1/mq5/connect` | Registrasi koneksi EA |

---

## 📊 Setup EA MQ5

### 1. Copy File EA
Copy `MQ5_FastAPI/EAFastConnector.mq5` ke:
```
C:\Users\[Kamu]\AppData\Roaming\MetaQuotes\Terminal\[ID]\MQL5\Experts\
```

### 2. Compile di MetaEditor
- Buka MetaEditor
- Buka `EAFastConnector.mq5`
- Tekan F7 untuk compile

### 3. Konfigurasi EA
- Drag EA ke chart (EURUSD H1 disarankan)
- Set URL backend: `http://localhost:8000`
- Aktifkan "Allow Algo Trading"
- Aktifkan "Allow WebRequest"

### 4. Tambahkan URL Backend
Di MetaTrader:
- Tools → Options → Expert Advisors
- Centang "Allow WebRequest for listed URL"
- Tambahkan: `http://localhost:8000`

---

## 🔧 Konfigurasi

### Backend (.env)
```env
GROQ_API_KEY=gsk_xxxxx
NEWS_API_KEY=xxxxx
DEBUG=false
MAX_RISK_PER_TRADE=0.02
```

### Parameter Input EA MQ5
| Parameter | Default | Penjelasan |
|-----------|---------|------------|
| BackendURL | http://localhost:8000 | Alamat backend |
| UseBackend | true | Aktifkan penggunaan backend |
| AnalysisInterval | 60 | Detik antar panggilan |
| GridDistance | 300 | Jarak grid (poin) |
| MaxRiskPerTrade | 2.0% | Risiko maksimum per trade |

---

## 🛡️ Fitur Manajemen Risiko

### Skoring Risiko Berbasis AI
- Risiko teknikal (30%)
- Risiko volatilitas (30%)
- Risiko berita (20%)
- Risiko keyakinan AI (20%)

### Circuit Breaker
- Batas rugi harian (default 10%)
- Batas drawdown (default 15%)
- Penutupan posisi otomatis

### Penyesuaian Dinamis
- Ukuran posisi berdasarkan skor risiko
- Stop loss berdasarkan volatilitas
- Take profit berdasarkan rasio risk-reward

---

## 📈 Contoh Respons API

### Sinyal Trading
```json
{
  "signal": "BUY",
  "risk_score": 0.35,
  "confidence": 0.78,
  "suggested_volume": 0.05,
  "suggested_sl": 1.08200,
  "suggested_tp": 1.09100,
  "risk_level": "MEDIUM",
  "news_caution": false
}
```

### Penilaian Risiko
```json
{
  "risk_score": 0.42,
  "risk_level": "MEDIUM",
  "max_allowed_volume": 0.08,
  "recommended_sl_distance": 0.00150,
  "news_risk": 0.2,
  "technical_risk": 0.4,
  "volatility_risk": 0.3,
  "warnings": []
}
```

---

## 🔍 Pengujian

### Uji Backend
```bash
# Cek kesehatan server
curl http://localhost:8000/health

# Ambil sinyal
curl -X POST http://localhost:8000/api/v1/trading/signal \
  -H "Content-Type: application/json" \
  -d '{"symbol":"EURUSD","bid":1.08500,"ask":1.08510,"spread":10}'
```

### Uji Koneksi EA
1. Buka MetaTrader
2. Cek tab Experts untuk pesan "Backend connected"
3. Pastikan dashboard muncul di chart

---

## 🐛 Troubleshooting

### Backend tidak mau start
- Cek versi Python (3.11+)
- Pastikan semua dependency terinstall
- Cek port 8000 tidak dipakai aplikasi lain

### EA tidak bisa konek
- Pastikan backend sedang berjalan
- Cek URL di pengaturan EA
- Pastikan WebRequest sudah diizinkan
- Cek pengaturan firewall

### Tidak ada analisa AI
- Pastikan GROQ_API_KEY sudah diisi di .env
- Cek log backend
- Coba tes dengan curl

---

## 📝 Pengembangan

### Menambah Endpoint Baru
1. Buat router di `app/routers/`
2. Daftarkan di `main.py`
3. Implementasikan logika di service terkait

### Menambah Service Baru
1. Buat service di `app/services/`
2. Import di router terkait
3. Tambahkan ke dependency injection

---

## ⚠️ Disclaimer

Sistem ini dibuat untuk tujuan edukasi. Trading melibatkan risiko besar. Selalu uji
dulu di akun demo. Jangan pernah trading dengan uang yang tidak siap kamu rugikan.
