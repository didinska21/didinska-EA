# Panduan Mulai Cepat

## Setup 5 Menit

### 1. Dapatkan API Key Gratis

**NewsAPI (100% Gratis)**
- Buka: https://newsapi.org/register
- Daftar pakai email
- Salin API key kamu
- Biaya: GRATIS (100 request/hari)

**Groq API (Cepat & Terjangkau)**
- Buka: https://console.groq.com/keys
- Buat akun (bisa langsung dapat API key gratis)
- Salin API key kamu
- Model yang dipakai: `openai/gpt-oss-120b`

### 2. Install di MetaTrader

1. Buka MetaTrader 5
2. Klik `File` → `Open Data Folder` (ini folder data MT5 kamu, beda dengan folder instalasi)
3. Copy file-file berikut:
   - `GroqNewsGridScalper.mq5` → `MQL5\Experts\`
   - Folder `Include\` (isinya `GroqAI.mqh` dan `NewsAPI.mqh`) → `MQL5\Experts\Include\`

> ⚠️ Penting: folder `Include` **harus** persis di `MQL5\Experts\Include\` (sebelahan
> dengan file `.mq5`-nya), **bukan** di `MQL5\Include\`. Ini karena EA memakai
> include relatif (`#include "Include\GroqAI.mqh"`), jadi MetaEditor akan mencarinya
> di folder yang sama dulu.

### 3. Compile

1. Buka `GroqNewsGridScalper.mq5` di MetaEditor
2. Tekan `F7` untuk compile
3. Pastikan muncul "0 errors" di Toolbox

### 4. Izinkan Web Request

1. Di MetaTrader: `Tools` → `Options` → `Expert Advisors`
2. Centang: "Allow WebRequest for listed URL"
3. Tambahkan URL berikut:
   - `https://newsapi.org`
   - `https://api.groq.com`

### 5. Pasang di Chart

1. Buka chart EURUSD atau XAUUSD (timeframe H1 atau H4)
2. Drag `GroqNewsGridScalper` dari Navigator ke chart
3. Isi API key kamu di parameter input
4. Centang "Allow Algo Trading"
5. Klik OK

### 6. Pastikan Berjalan

Cek tab Experts untuk pesan:
```
GroqNewsGridScalper Initialized
AI Analysis: ENABLED
News Filter: ENABLED
```

Cek juga chart untuk tampilan dashboard.

---

## Pengaturan yang Disarankan

### Konservatif (Mulai di Sini)
```
MaxRiskPerTrade: 1.0%
MaxDailyLoss: 5.0%
GridOrders: 1
GridDistance: 400
```

### Standar
```
MaxRiskPerTrade: 2.0%
MaxDailyLoss: 10.0%
GridOrders: 2
GridDistance: 300
```

### Agresif (Khusus yang Berpengalaman)
```
MaxRiskPerTrade: 3.0%
MaxDailyLoss: 15.0%
GridOrders: 3
GridDistance: 250
```

---

## Apa yang Dikerjakan AI

### Setiap 5 Menit (bisa diatur):
1. Ambil berita terbaru untuk pasangan mata uang kamu
2. Analisa indikator teknikal
3. Hitung skor risiko (0-100%)
4. Buat sinyal (BUY/SELL/HOLD)
5. Sesuaikan ukuran posisi & stop loss

### Level Skor Risiko:
- **0-30%**: Risiko rendah, trading normal
- **30-60%**: Risiko sedang, ukuran posisi sedikit dikurangi
- **60-80%**: Risiko tinggi, trading minimal
- **80-100%**: Ekstrem, tidak ada order baru

### Proteksi Berita:
- **30 menit sebelum** berita berdampak tinggi → mode waspada
- **Ukuran posisi** dipotong 50%
- **Batas spread** diperketat 20%
- **Hanya trade dengan keyakinan tinggi** yang diizinkan

---

## Penjelasan Dashboard

```
========================================
 GROQ AI GRID SCALPER
========================================
 Engine     : OPERATIONAL          ← Status EA saat ini
 Balance    : 1000.00 USD          ← Saldo akun
 Equity     : 1005.50 USD          ← Ekuitas saat ini
 P/L Today  : +5.50 USD            ← Untung/rugi hari ini
 Spread     : 12 pts               ← Spread saat ini
----------------------------------------
 AI Status  : Risk: 35% | Conf: 78% | Signal: BUY
 News       : CLEAR | Sentiment: 0.15
----------------------------------------
 RSI(14)    : 55.3                 ← Nilai RSI
 ATR(14)    : 0.00850              ← Volatilitas
 EMA20/50   : 1.08500 / 1.08200    ← Indikator tren
========================================
```

---

## Troubleshooting

### "Tidak ada order yang jalan"
1. Cek spread > MaxSpread? Tunggu atau pindah ke broker dengan spread lebih rendah
2. Cek status AI - apakah HOLD? AI sedang menunggu momen yang lebih jelas
3. Cek status berita - apakah CAUTION? Mode waspada berita sedang aktif

### "WebRequest failed"
1. Pastikan URL sudah ditambahkan di Options → Expert Advisors
2. Cek koneksi internet
3. Restart MetaTrader

### "API key invalid"
1. NewsAPI: cek email untuk verifikasi akun
2. Groq: cek dashboard di console.groq.com apakah key masih aktif
3. Coba jalankan tanpa API key dulu (EA otomatis pakai mode analisa cadangan/built-in)

---

## Pasangan Terbaik

**Disarankan:**
- EURUSD (paling likuid)
- GBPUSD
- USDJPY
- XAUUSD (emas)
- EURGBP

**Hindari (spread terlalu lebar):**
- Pasangan eksotis (USDTRY, USDZAR)
- Pasangan minor di luar jam aktif

---

## Sesi Terbaik

**Jam Aktif:**
- London: 07:00-16:00 UTC
- New York: 12:00-21:00 UTC
- Overlap: 12:00-16:00 UTC (paling ramai)

**Hindari:**
- Jumat sore
- Minggu malam
- Hari libur besar

---

## Peringatan Risiko

⚠️ EA ini trading dengan uang sungguhan. Selalu:
- Mulai dengan akun demo
- Gunakan uang yang siap kamu relakan kalau rugi
- Pantau secara berkala
- Jangan langsung pakai pengaturan risiko maksimal
- Jaga kerahasiaan API key kamu
