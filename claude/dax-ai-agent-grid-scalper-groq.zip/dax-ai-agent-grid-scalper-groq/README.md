<div align="center">

# DAX AI Agent Grid Scalper (Groq Edition)

### Expert Advisor MetaTrader 5 + AI (Groq) + Backend Python FastAPI

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.11](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/downloads/)
[![MetaTrader 5](https://img.shields.io/badge/MetaTrader-5-green.svg)](https://www.metatrader5.com/)
[![Docker](https://img.shields.io/badge/Docker-Ready-2496ED.svg)](https://www.docker.com/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-009688.svg)](https://fastapi.tiangolo.com/)
[![Groq](https://img.shields.io/badge/AI-Groq%20openai%2Fgpt--oss--120b-orange.svg)](https://groq.com)

**Sistem trading otomatis yang menggabungkan grid trading dengan analisa AI dari Groq
(model `openai/gpt-oss-120b`), filter berita real-time, dan manajemen risiko otomatis
untuk scalping forex/emas di MetaTrader 5.**

Ini adalah versi "remake" dari proyek DAX AI Agent Grid Scalper — fungsinya
**sama persis** dengan versi aslinya, hanya saja:
- Bagian AI diganti dari DeepSeek → **Groq AI (`openai/gpt-oss-120b`)**
- Dokumentasi ditulis ulang dalam **bahasa Indonesia yang mudah dipahami**
- Struktur kode & penamaan file dirapikan agar lebih gampang dibaca pemula

[Mulai Cepat](#mulai-cepat) | [Cara Kerja](#cara-kerja) | [Varian EA](#varian-ea) | [Konfigurasi](#konfigurasi) | [FAQ](#faq)

</div>

---

## Ringkasan Singkat

> **Apa ini?** Expert Advisor (robot trading) open-source (MIT) untuk MetaTrader 5,
> ditulis dengan MQL5 — dan backend Python FastAPI opsional untuk komputasi AI terpusat.
> **AI-nya**: Groq AI (model `openai/gpt-oss-120b`) menghasilkan sinyal BUY/SELL/HOLD
> lengkap dengan skor keyakinan (confidence) dan skor risiko 0-100%.
> **Berita**: Filter sentimen berita forex real-time dari NewsAPI.org, otomatis masuk
> "mode waspada" 30 menit sebelum rilis berita berdampak besar.
> **Risiko**: Ada rem darurat otomatis (circuit breaker) — batas rugi harian 10%,
> batas floating drawdown 15% — plus ukuran posisi & stop loss yang menyesuaikan risiko.
> **Biaya**: Software gratis. NewsAPI gratis (100 request/hari). Groq punya API yang
> sangat cepat dan terjangkau (cek harga terbaru di https://groq.com/pricing).
> **Pasang**: 5 menit untuk mode standalone (copy file `.mq5` → compile → isi API key).
> Untuk backend, tinggal `docker-compose up -d`.

---

## Kenapa Proyek Ini?

| | DAX AI Grid Scalper | EA MT5 biasa | Trading manual |
|---|---|---|---|
| **Analisa pasar** | AI Groq + sentimen berita | Aturan tetap (fixed rule) | Insting manusia |
| **Adaptasi risiko** | Skor risiko dinamis 0-100% | Parameter statis | Naluri, kadang emosional |
| **Sadar berita** | Mode waspada otomatis | Tidak ada | Harus cek manual |
| **Operasional** | 24/5 otomatis | 24/5 otomatis | Terbatas jam kerja |
| **Kontrol risiko** | Rem darurat + AI adjustment | SL/TP dasar | Tergantung disiplin |
| **Kode sumber** | Terbuka penuh (MIT) | Biasanya tertutup | - |
| **Biaya** | Gratis + API murah | $50–$5000+ | Waktu & tenaga |

---

## Fitur Utama

### Mesin Trading Bertenaga AI

| Fitur | Penjelasan |
|---|---|
| **Integrasi Groq AI** | Analisa pasar berbasis LLM, model `openai/gpt-oss-120b` |
| **Analisa Sentimen** | Skor sentimen berita real-time untuk pasangan mata uang |
| **Sinyal Trading** | Rekomendasi BUY/SELL/HOLD lengkap dengan tingkat keyakinan |
| **Skor Risiko** | Penilaian risiko dinamis 0-100% dari data teknikal + fundamental |

### Grid Trading Canggih

| Fitur | Penjelasan |
|---|---|
| **Grid Breakout** | Penempatan grid dinamis mengikuti pergerakan harga |
| **Ukuran Lot Cerdas** | Lot disesuaikan otomatis berdasarkan skor risiko AI |
| **Stop Loss Adaptif** | SL berbasis ATR yang dioptimalkan AI |
| **Trailing & Break-Even** | Perlindungan profit otomatis |
| **Grid Fibonacci** | Jarak grid mengikuti rasio Fibonacci untuk strategi trend |
| **Multi Timeframe** | Dukungan M1, M5, M15 dengan parameter teroptimasi |

### Intelijen Berita Real-Time

| Fitur | Penjelasan |
|---|---|
| **Integrasi NewsAPI** | Berita forex real-time dari 100.000+ sumber |
| **Kalender Ekonomi** | Deteksi & peringatan event berdampak tinggi |
| **Mode Waspada Berita** | Otomatis kurangi risiko 30 menit sebelum berita besar |
| **Skor Sentimen** | Analisa sentimen pasar berbasis NLP dari berita |

### Manajemen Risiko

| Fitur | Penjelasan |
|---|---|
| **Circuit Breaker** | Batas rugi harian & drawdown, otomatis tutup posisi |
| **Batas Diperketat AI** | Batas lebih ketat saat AI mendeteksi risiko tinggi |
| **Batas Ukuran Posisi** | Risiko maksimum per trade ditegakkan ketat |
| **Proteksi Spread** | Filter spread dinamis saat volatilitas tinggi |

---

## Cara Kerja

```
┌──────────────────────────────────────────────────────────────────┐
│                   Sistem Trading DAX AI (Groq Edition)            │
├─────────────────────────┬────────────────────────────────────────┤
│    MetaTrader 5 (EA)    │       Backend FastAPI (Python)          │
│                         │                                        │
│  ┌───────────────────┐  │  ┌──────────────────────────────────┐  │
│  │ Grid Trading      │  │  │ Layanan Groq AI                  │  │
│  │ Eksekusi Order    │  │  │ ├── Analisa Pasar                 │  │
│  │ Cek Risiko        │  │  │ ├── Pembuatan Sinyal              │  │
│  │ Dashboard (HTML)  │  │  │ └── Skoring Risiko                │  │
│  └───────────────────┘  │  └──────────────────────────────────┘  │
│                         │                                        │
│  ┌───────────────────┐  │  ┌──────────────────────────────────┐  │
│  │ Modul MQ5         │  │  │ Layanan Berita                   │  │
│  │ ├── GroqAI.mqh    │  │  │ ├── Integrasi NewsAPI             │  │
│  │ └── NewsAPI.mqh   │  │  │ ├── Analisa Sentimen              │  │
│  └───────────────────┘  │  │ └── Kalender Ekonomi              │  │
│                         │  └──────────────────────────────────┘  │
│                         │                                        │
│                         │  ┌──────────────────────────────────┐  │
│                         │  │ Manajemen Risiko                  │  │
│                         │  │ ├── Circuit Breaker               │  │
│                         │  │ ├── Ukuran Posisi                 │  │
│                         │  │ └── SL/TP Dinamis                 │  │
│                         │  └──────────────────────────────────┘  │
└─────────────────────────┴────────────────────────────────────────┘
         │ HTTP (REST)                      │
         └──────────────────────────────────┘
```

### Mode Standalone vs FastAPI

| Mode | Cara Kerja | Cocok Untuk |
|------|-------------|----------|
| **Standalone** | EA memanggil Groq + NewsAPI langsung lewat HTTP | Setup simpel, satu PC |
| **FastAPI** | EA memanggil backend Python, backend yang urus AI | Multi-perangkat, risiko lanjutan, skalabilitas |

---

## Struktur Proyek

```
dax-ai-agent-grid-scalper-groq/
├── GroqNewsGridScalper.mq5          # EA standalone utama (flagship)
├── Include/
│   ├── GroqAI.mqh                    # Modul integrasi Groq AI
│   └── NewsAPI.mqh                   # Modul integrasi NewsAPI
├── Config/
│   └── EA_Config.ini                 # Contoh konfigurasi EA
├── Backend/                          # Backend Python FastAPI
│   ├── app/
│   │   ├── main.py                   # Entry point FastAPI
│   │   ├── core/                     # Konfigurasi & database
│   │   ├── routers/                  # Handler endpoint API
│   │   ├── services/                 # Logika bisnis (Groq, berita, risiko)
│   │   └── models/                   # Skema Pydantic
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── requirements.txt
│   └── .env.example
├── MQ5_FastAPI/                      # Varian EA yang terhubung ke backend
│   ├── EAFastConnector.mq5
│   ├── EAFastConnector_v3.mq5
│   ├── DAX_M5_Standalone.mq5
│   ├── DAX_FibATR_Trend.mq5
│   └── Fibonation_Grid.mq5
├── Scripts/
│   └── TestAPIs.mq5                  # Skrip uji koneksi API
├── legacy/                           # Bot Python generasi sebelumnya (trend_scalper)
└── docs/
    └── index.html                    # Landing page (GitHub Pages)
```

---

## Mulai Cepat

### Mode Standalone (5 menit)

**1. Dapatkan API Key**

| API | Biaya | Daftar |
|-----|------|---------|
| NewsAPI | **Gratis** (100 request/hari) | [newsapi.org/register](https://newsapi.org/register) |
| Groq AI | Sangat murah/cepat | [console.groq.com/keys](https://console.groq.com/keys) |

**2. Install di MetaTrader 5**

```bash
# Copy DUA-DUANYA ke dalam MQL5/Experts/ (file EA + folder Include di sebelahnya)
Copy GroqNewsGridScalper.mq5   → MQL5/Experts/
Copy Include/                  → MQL5/Experts/Include/
```

> EA ini memakai include relatif (`"Include\NewsAPI.mqh"`), jadi folder `Include/`
> WAJIB ada tepat di sebelah file `.mq5` di dalam `MQL5/Experts/`.

**3. Compile & Konfigurasi**

1. Buka MetaEditor, tekan `F7` untuk compile
2. Drag EA ke chart EURUSD atau XAUUSD (timeframe H1/H4 disarankan)
3. Isi API key Groq & NewsAPI di parameter input EA
4. Aktifkan "Allow WebRequest" dengan URL berikut:
   - `https://newsapi.org`
   - `https://api.groq.com`

**4. Verifikasi**

Cek tab Experts untuk pesan `AI Analysis: ENABLED` dan dashboard on-chart yang muncul.

### Mode FastAPI (10 menit)

```bash
cd Backend

# Siapkan environment
copy .env.example .env
# Edit .env, isi GROQ_API_KEY dan NEWS_API_KEY

# Jalankan dengan Docker (disarankan)
docker-compose up -d

# ATAU jalankan lokal
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Lalu arahkan EA (`MQ5_FastAPI/EAFastConnector_v3.mq5`) ke `http://localhost:8000`.

Detail lengkap backend: [README_FastAPI.md](README_FastAPI.md) · Panduan instalasi: [QUICKSTART.md](QUICKSTART.md)

---

## Varian EA

| EA | Strategi | Timeframe | Mode | Cocok Untuk |
|----|----------|-----------|------|----------|
| **GroqNewsGridScalper** | Grid + AI + Berita | M1-H4 | Standalone | Trading lengkap dengan AI |
| **EAFastConnector / _v3** | Grid + Backend | M1-H4 | FastAPI | Setup yang bisa diskalakan |
| **DAX_M5_Standalone** | Grid (optimasi M5) | M5 | Standalone | Scalping cepat |
| **DAX_FibATR_Trend** | Trend Fibonacci + ATR | M5-M30 | Standalone | Ikut tren |
| **Fibonation_Grid** | Grid Fibonacci | M5 | Standalone | Grid dengan jarak Fibonacci |

> Catatan: EA selain `GroqNewsGridScalper` dan `EAFastConnector*` **tidak memakai AI**
> sama sekali (murni aturan teknikal/Fibonacci/ATR) — jadi tidak ada yang perlu diganti
> di sana, fungsinya persis seperti versi asli.

---

## Konfigurasi

### Profil Risiko

| Profil | Risiko/Trade | Rugi Harian Max | Order Grid | Jarak Grid | Cocok Untuk |
|---------|-----------|------------|-------------|---------------|-------------|
| **Konservatif** | 1.0% | 5.0% | 1 | 400 | Pemula |
| **Standar** | 2.0% | 10.0% | 2 | 300 | Kebanyakan trader |
| **Agresif** | 3.0% | 15.0% | 3 | 250 | Trader berpengalaman |

### Parameter AI

| Parameter | Default | Penjelasan |
|-----------|---------|----------|
| `InpUseAIAnalysis` | `true` | Aktifkan analisa Groq AI |
| `InpUseNewsFilter` | `true` | Aktifkan filter berdasarkan berita |
| `InpAIAnalysisInterval` | `300` | Jeda antar panggilan AI (detik) |
| `InpMaxRiskPerTrade` | `2.0%` | Risiko maksimum per trade |
| `InpDynamicPositionSizing` | `true` | Ukuran lot otomatis dari AI |
| `InpDynamicStopLoss` | `true` | Stop loss otomatis dari AI |

### Circuit Breaker (Rem Darurat)

| Parameter | Default | Aksi |
|-----------|---------|--------|
| `InpMaxDailyLossPct` | `10.0%` | Tutup semua posisi |
| `InpMaxDrawdownPct` | `15.0%` | Hentikan trading darurat |
| AI-Adjusted Limits | otomatis | Batas diperketat saat risiko AI > 70% |

---

## Manajemen Risiko

### Skor Risiko AI

```
Skor Risiko = Teknikal (30%) + Volatilitas (30%) + Berita (20%) + Keyakinan AI (20%)

0-30%   → Risiko Rendah  → Ukuran posisi normal
30-60%  → Risiko Sedang  → Ukuran posisi dikurangi
60-80%  → Risiko Tinggi  → Trading minimal
80-100% → Ekstrem        → Tidak ada order baru
```

### Proteksi Berita

- **30 menit sebelum** berita berdampak besar → mode waspada aktif
- **Ukuran posisi** dipotong 50%
- **Batas spread** diperketat 20%
- **Hanya trade dengan keyakinan tinggi** yang diizinkan

---

## Referensi API (Mode FastAPI)

```
POST /api/v1/trading/signal      # Sinyal trading instan
POST /api/v1/trading/analyze     # Analisa pasar lengkap
GET  /api/v1/trading/dashboard   # Data dashboard

POST /api/v1/risk/assess            # Penilaian risiko
POST /api/v1/risk/position-size     # Ukuran posisi
POST /api/v1/risk/dynamic-sl        # Stop loss dinamis
POST /api/v1/risk/circuit-breakers  # Cek rem darurat

GET /api/v1/news/{symbol}              # Berita forex
GET /api/v1/news/{symbol}/sentiment    # Skor sentimen
GET /api/v1/news/{symbol}/high-impact  # Cek berita berdampak tinggi

POST /api/v1/scalp/plan  # Endpoint "all-in-one": sinyal + risiko + grid sekaligus
```

Dokumentasi Swagger lengkap tersedia di `http://localhost:8000/docs`.

---

## Backtesting

Skrip riset & backtest ada di `Backend/` (mis. `backtest.py`, `multi_backtest.py`,
`optimize.py`, `optimize_m5.py`) — semuanya memakai mesin simulasi grid di
`Backend/app/services/backtest_engine.py`, tidak ada bagian yang memakai AI
(jadi tidak perlu diubah untuk pindah ke Groq).

> **Peringatan**: hasil backtest masa lalu tidak menjamin hasil di masa depan.
> Selalu uji dulu di akun demo.

---

## Rekomendasi

### Pasangan Terbaik

| Tingkat | Pasangan |
|------|-------|
| **Utama** | EURUSD, GBPUSD, USDJPY, XAUUSD |
| **Sekunder** | EURGBP, AUDUSD, USDCAD |
| **Hindari** | Pasangan eksotis (USDTRY, USDZAR), pasangan minor di luar jam aktif |

### Sesi Terbaik

| Sesi | Waktu (UTC) | Rating |
|---------|-----------|--------|
| London | 07:00-16:00 | Bagus |
| New York | 12:00-21:00 | Bagus |
| **Overlap** | **12:00-16:00** | **Terbaik** |
| Asia | 23:00-08:00 | Hindari |

---

## Kontribusi

Kontribusi sangat diterima! Baca [CONTRIBUTING.md](CONTRIBUTING.md) untuk panduannya.

1. Fork repository ini
2. Buat branch fitur baru (`git checkout -b fitur/nama-fitur`)
3. Commit perubahan (`git commit -m 'Tambah fitur X'`)
4. Push ke branch (`git push origin fitur/nama-fitur`)
5. Buka Pull Request

---

## Dokumentasi Lengkap

| Dokumen | Isi |
|----------|----------|
| [QUICKSTART.md](QUICKSTART.md) | Panduan instalasi langkah demi langkah |
| [README_FastAPI.md](README_FastAPI.md) | Arsitektur backend + referensi API lengkap |
| [CHANGELOG.md](CHANGELOG.md) | Riwayat perubahan |
| [CONTRIBUTING.md](CONTRIBUTING.md) | Cara berkontribusi |
| [SECURITY.md](SECURITY.md) | Kebijakan keamanan + cara aman simpan API key |

---

## FAQ

**Kenapa AI-nya diganti ke Groq?**
Groq menyediakan inferensi LLM yang sangat cepat (hitungan milidetik) dan mendukung
model open-weight `openai/gpt-oss-120b` dengan harga bersaing — cocok untuk kebutuhan
analisa pasar yang berulang setiap beberapa menit.

**Apakah fungsi aslinya berubah?**
Tidak. Semua logika grid trading, manajemen risiko, filter berita, dan circuit
breaker tetap identik dengan versi asli. Yang berubah hanya "penyedia otak AI"-nya.

**Apakah saya wajib pakai backend FastAPI?**
Tidak. Mode standalone (EA memanggil Groq & NewsAPI langsung) sudah cukup untuk
kebanyakan pengguna. Backend FastAPI dipakai kalau butuh kontrol lebih (multi-akun,
logging terpusat, dsb).

---

## Lisensi

Proyek ini memakai Lisensi MIT — lihat file [LICENSE](LICENSE) untuk detailnya.

---

## Disclaimer

Expert Advisor ini beserta seluruh kode terkait dibuat untuk **tujuan edukasi dan
riset**. Trading forex dengan margin memiliki risiko tinggi dan mungkin tidak cocok
untuk semua orang. Kinerja masa lalu tidak menjamin hasil di masa depan. Selalu
trading secara bertanggung jawab dan jangan pernah menggunakan uang yang tidak siap
Anda rugikan. Penulis tidak bertanggung jawab atas kerugian finansial apa pun yang
timbul dari penggunaan software ini.

---

<div align="center">

**Dibangun dengan Groq AI, MetaTrader 5, Python FastAPI, dan Docker**

</div>
