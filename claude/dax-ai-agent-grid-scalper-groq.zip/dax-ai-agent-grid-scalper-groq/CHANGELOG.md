# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.1.5] - Pengaman ukuran lot (ditemukan lot janggal di akun nyata)

### Ditambahkan (Added)
- **Input baru `InpMaxLotSize`** (default `0.05`) di `GroqNewsGridScalper.mq5` —
  batas keras (hard cap) untuk lot per order. Berapa pun hasil hitungan
  `CalculateRiskAdjustedSize()`, lot **tidak akan pernah** melebihi angka ini.
  Ini ditambahkan setelah ditemukan kasus nyata: hasil hitungan otomatis
  sempat menghasilkan lot 1.10–1.26 pada akun $2.366 di XAUUSD (nilai
  transaksi setara ratusan ribu dolar dari saldo segitu — sangat berbahaya),
  kemungkinan karena data `SYMBOL_TRADE_TICK_VALUE`/`SYMBOL_TRADE_TICK_SIZE`
  dari broker tidak sesuai asumsi rumus untuk simbol tersebut.
- **Log diagnosa** di `GroqAI.mqh` (`CalculateRiskAdjustedSize`) dan
  `GroqNewsGridScalper.mq5` (`GetSmartLotSize`) yang mencetak rincian
  perhitungan (saldo, risk_amount, tick_value, tick_size, lot mentah sebelum
  dipotong) ke tab Experts, supaya kalau lot terlihat janggal lagi,
  penyebabnya langsung kelihatan tanpa perlu menebak.

### Catatan
- Akar masalah pastinya (kenapa tick_value/tick_size broker menghasilkan lot
  sebesar itu) belum 100% dipastikan — perlu log baru dari akun yang
  bersangkutan untuk diagnosa lebih lanjut. `InpMaxLotSize` adalah pengaman
  sementara yang WAJIB ada terlepas dari akar masalahnya.

## [2.1.4] - Perbaikan alamat domain NewsAPI yang salah

### Diperbaiki (Fixed)
- **Bug**: `Include/NewsAPI.mqh` (dan semua dokumentasi) memakai alamat
  `https://api.newsapi.org` untuk memanggil NewsAPI.org — padahal alamat
  resminya `https://newsapi.org` (tanpa subdomain "api."). Akibatnya modul
  berita **selalu** gagal konek dan EA otomatis jatuh ke "offline mode"
  (data contoh statis), membuat mode "News: CAUTION" menyala terus-menerus
  tanpa alasan nyata. Bug ini bawaan dari proyek DeepSeek asli (backend
  Python kebetulan sudah benar dari awal, hanya versi MQL5 yang salah).
  Sudah dibetulkan di kode dan seluruh dokumentasi WebRequest.

## [2.1.3] - Perbaikan bug JSON payload rusak (HTTP 400)

### Diperbaiki (Fixed)
- **Bug**: teks `prompt` yang dikirim ke Groq berisi banyak baris baru (`\n`)
  dan tanda kutip untuk format yang enak dibaca manusia, tapi ditempel
  apa adanya ke JSON tanpa di-escape dulu → Groq menolak dengan
  `HTTP 400: invalid character '\n' in string literal`, dan EA tidak pernah
  dapat sinyal dari AI. Ditambahkan fungsi `JsonEscape()` di `GroqAI.mqh`
  yang meng-escape backslash, tanda kutip, dan baris baru dengan benar
  sebelum dikirim. Bug ini juga bawaan dari kode asli, baru ketahuan
  setelah pesan error HTTP-nya berhasil ditampilkan (lihat versi 2.1.2).

## [2.1.2] - Perbaikan bug parsing balasan Groq (bug lama, baru ketahuan)

### Diperbaiki (Fixed)
- **Bug utama**: `GroqAI.mqh` membaca sinyal/skor risiko langsung dari "amplop"
  JSON mentah balasan API (`{"choices":[{"message":{"content":"..."}}]}`),
  padahal hasil analisa AI yang sebenarnya ada **di dalam** field `content`
  dalam bentuk teks yang di-escape (`\"signal\":\"BUY\"`, bukan `"signal":"BUY"`).
  Akibatnya EA **selalu** membaca `Risk=0.00 Signal=SIGNAL_NONE` walaupun AI
  sebenarnya sudah menjawab dengan benar — EA jadi seperti "diam" terus,
  tidak pernah entry. Sekarang field `content` dibongkar & di-unescape dulu
  (`ExtractMessageContent()`) sebelum dibaca. Bug ini sudah ada sejak versi
  DeepSeek yang asli, cuma baru ketahuan sekarang setelah dicoba jalan nyata.
- Tambah `"response_format":{"type":"json_object"}` di request ke Groq supaya
  balasan AI selalu berupa JSON murni (lebih konsisten).
- `ExtractSignal()` sekarang toleran kalau AI menulis `"signal": "BUY"` (pakai
  spasi setelah titik dua).
- `WebRequest(...)` sekarang benar-benar dicek status HTTP-nya (200 = sukses).
  Kalau gagal (API key salah, model tidak ditemukan, rate limit, dsb), pesan
  error dari Groq sekarang **dicetak ke tab Experts** supaya kelihatan
  penyebabnya, bukan diam-diam dianggap "tidak ada sinyal".

## [2.1.0] - Groq Edition (remake)

### Diubah (Changed)
- **Penyedia AI diganti ke Groq**: Semua pemanggilan analisa AI (di `GroqAI.mqh`,
  `groq_service.py`, dan modul LLM pada proyek `legacy/`) sekarang memakai
  [Groq API](https://console.groq.com) dengan model `openai/gpt-oss-120b`,
  menggantikan DeepSeek. Endpoint: `https://api.groq.com/openai/v1/chat/completions`.
- **File & variabel dinamai ulang** agar jelas: `DeepSeekAI.mqh` → `GroqAI.mqh`,
  `DeepSeekNewsGridScalper_V2.mq5` → `GroqNewsGridScalper.mq5`,
  `deepseek_service.py` → `groq_service.py`, `DEEPSEEK_API_KEY` → `GROQ_API_KEY`, dst.
- **Dokumentasi ditulis ulang dalam Bahasa Indonesia** (README, QUICKSTART,
  README_FastAPI) supaya lebih mudah dipahami, tanpa mengubah fungsi apa pun.

### Tidak berubah (Unchanged)
- Seluruh logika grid trading, circuit breaker, filter berita, dan perhitungan
  risiko **identik** dengan versi sebelumnya — hanya penyedia AI yang diganti.

## [2.0.0] - 2026-08-25

### Added
- **Groq AI integration**: LLM-powered market analysis with BUY/SELL/HOLD signal generation, confidence scoring, and 0-100% dynamic risk assessment (`GroqAI.mqh`, `groq_service.py`)
- **NewsAPI intelligence**: Real-time forex news sentiment scoring, high-impact event detection, and automatic pre-news caution mode (30 min before events, -50% position size, +20% spread tightening) (`NewsAPI.mqh`, `news_service.py`)
- **Grid trading engine**: Breakout-based grid with configurable distance/orders, trailing stops, and break-even protection
- **FastAPI backend**: Python 3.11 REST API with 15+ endpoints covering trading signals, risk assessment, position sizing, dynamic SL/TP, circuit breakers, and news queries (`/docs` Swagger UI included)
- **Circuit breaker risk management**: Daily loss limit (default 10%), max drawdown halt (default 15%), AI-adjusted limits when risk score > 70%
- **EA variants**: `GroqNewsGridScalper` (flagship standalone), `EAFastConnector` (FastAPI mode), `DAX_M5_Standalone` (M5 scalping), `DAX_FibATR_Trend` (Fibonacci ATR trend), `Fibonation_Grid` (Fibonacci-spaced grid)
- **Docker support**: Production-ready Dockerfile + docker-compose.yml with health checks
- **On-chart dashboard**: Real-time engine status, balance/equity, AI risk/confidence/signal, news status, RSI/ATR/EMA indicators
- **SEO landing page** with FAQ, structured data (SoftwareApplication, FAQPage, HowTo schemas), Open Graph, and `llms.txt` / `llms-full.txt` for LLM discoverability
- **CI pipeline**: GitHub Actions with Python lint (ruff), Docker build test, MQL5 source validation

### Risk Management Details
- Micro account support: auto-reduced SL to 250 pts for small balances, 25% DD limit under minimum balance threshold
- Drawdown breaker: peak-equity tracking, daily reset, halts new trading instead of force-closing positions
- Grid overtrading fix: 30-minute cooldown between grid activations matching Python backtest logic

### Fixed
- Fibonacci array out-of-range error (size 6 → 7)
- Fibonacci EA optimized SL/TP calculation (atr*0.9*8, 1x/2x spacing)
- Grid overtrading via time-based cooldown

## [1.0.0] - Initial Development

### Added
- Basic grid trading engine
- Simple risk controls
- Standard trailing stops

[2.0.0]: https://github.com/foeed/dax-ai-agent-grid-scalper/releases/tag/v2.0.0
