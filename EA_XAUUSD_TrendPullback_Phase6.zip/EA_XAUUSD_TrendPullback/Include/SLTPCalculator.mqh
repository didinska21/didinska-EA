//+------------------------------------------------------------------+
//| SLTPCalculator.mqh                                               |
//| Computes SL/TP objectively — no visual/subjective judgment.      |
//|                                                                   |
//| SL  = lowest low / highest high over N CLOSED bars, +/- ATR buffer|
//| TP  = Entry +/- (SL distance x RR multiple)                      |
//|                                                                   |
//| DESIGN NOTE: the Phase 2 draft spec allowed TP to target either  |
//| "previous swing high/low" OR an ATR multiple — two options is    |
//| itself a subjectivity gap (which one, and when?). This module    |
//| resolves it to a single deterministic rule: RR-multiple of SL    |
//| distance. Documented here so the change is traceable.            |
//|                                                                   |
//| Also enforces the broker's minimum stop distance (SYMBOL_TRADE_  |
//| STOPS_LEVEL) — if a valid SL/TP would violate it, the setup is   |
//| rejected rather than forced closer, since forcing it would       |
//| silently change the risk actually taken.                          |
//+------------------------------------------------------------------+
#ifndef __SLTPCALCULATOR_MQH__
#define __SLTPCALCULATOR_MQH__

#include "..\Include\Enums.mqh"
#include "..\Include\Logger.mqh"

class CSLTPCalculator
  {
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   int               m_swing_lookback;
   double            m_sl_buffer_atr_mult;
   double            m_min_rr;
   CLogger          *m_logger;

public:
                     CSLTPCalculator() { m_logger = NULL; }

   bool              Init(string symbol, ENUM_TIMEFRAMES tf, int swing_lookback,
                           double sl_buffer_atr_mult, double min_rr, CLogger *logger)
     {
      m_symbol             = symbol;
      m_tf                 = tf;
      m_swing_lookback     = swing_lookback;
      m_sl_buffer_atr_mult = sl_buffer_atr_mult;
      m_min_rr             = min_rr;
      m_logger             = logger;
      return true;
     }

   // Fills sl_price/tp_price. Returns false if the setup should be REJECTED
   // (e.g. would violate broker's minimum stop distance) rather than forced.
   bool              Calculate(ENUM_TREND_DIRECTION direction, double atr_value, double entry_price,
                                double &sl_price, double &tp_price, string &reason_if_invalid)
     {
      double point = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
      double min_stop_points = (double)SymbolInfoInteger(m_symbol, SYMBOL_TRADE_STOPS_LEVEL);
      double min_stop_distance = min_stop_points * point;

      if(direction == TREND_UP)
        {
         int idx = iLowest(m_symbol, m_tf, MODE_LOW, m_swing_lookback, 1); // skip forming bar
         if(idx < 0)
           {
            reason_if_invalid = "iLowest failed to locate a swing low";
            return false;
           }
         double swing_low = iLow(m_symbol, m_tf, idx);
         sl_price = swing_low - (atr_value * m_sl_buffer_atr_mult);

         double sl_distance = entry_price - sl_price;
         if(sl_distance <= 0)
           {
            reason_if_invalid = "Computed SL is not below entry price (invalid swing/ATR combination)";
            return false;
           }
         if(sl_distance < min_stop_distance)
           {
            reason_if_invalid = StringFormat("SL distance %.5f below broker min stop distance %.5f — setup rejected, not forced",
                                              sl_distance, min_stop_distance);
            return false;
           }

         tp_price = entry_price + (sl_distance * m_min_rr);
        }
      else if(direction == TREND_DOWN)
        {
         int idx = iHighest(m_symbol, m_tf, MODE_HIGH, m_swing_lookback, 1);
         if(idx < 0)
           {
            reason_if_invalid = "iHighest failed to locate a swing high";
            return false;
           }
         double swing_high = iHigh(m_symbol, m_tf, idx);
         sl_price = swing_high + (atr_value * m_sl_buffer_atr_mult);

         double sl_distance = sl_price - entry_price;
         if(sl_distance <= 0)
           {
            reason_if_invalid = "Computed SL is not above entry price (invalid swing/ATR combination)";
            return false;
           }
         if(sl_distance < min_stop_distance)
           {
            reason_if_invalid = StringFormat("SL distance %.5f below broker min stop distance %.5f — setup rejected, not forced",
                                              sl_distance, min_stop_distance);
            return false;
           }

         tp_price = entry_price - (sl_distance * m_min_rr);
        }
      else
        {
         reason_if_invalid = "Direction is TREND_NONE, cannot calculate SL/TP";
         return false;
        }

      return true;
     }
  };

#endif // __SLTPCALCULATOR_MQH__
