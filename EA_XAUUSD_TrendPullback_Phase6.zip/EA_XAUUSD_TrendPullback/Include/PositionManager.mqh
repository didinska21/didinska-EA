//+------------------------------------------------------------------+
//| PositionManager.mqh                                              |
//| Handles breakeven and trailing-stop logic for open positions.    |
//|                                                                   |
//| BUG CAUGHT DURING DESIGN (worth documenting): the naive approach |
//| of computing "1R" as |entry - current_SL| breaks the moment SL   |
//| is first moved to breakeven — after that, entry-SL is ~0, and    |
//| every subsequent R-multiple calculation is wrong. Fix: the        |
//| ORIGINAL SL distance is persisted in a Global Variable at entry   |
//| time (keyed by position ticket) and read back here, independent  |
//| of wherever the live SL currently sits. Global Variables also    |
//| survive terminal/VPS restart, consistent with the project's      |
//| restart-resilience requirement.                                  |
//|                                                                   |
//| Runs every tick (not gated to new-bar) because protecting an     |
//| open position should react immediately to price, unlike signal   |
//| detection which is deliberately bar-based to avoid noise.        |
//+------------------------------------------------------------------+
#ifndef __POSITIONMANAGER_MQH__
#define __POSITIONMANAGER_MQH__

#include "..\Include\Enums.mqh"
#include "..\Include\Logger.mqh"

class CPositionManager
  {
private:
   string   m_symbol;
   long     m_magic;
   double   m_breakeven_rr;
   double   m_trailing_activate_rr;
   double   m_trailing_atr_mult;
   int      m_breakeven_buffer_points;
   CLogger *m_logger;

   string   OrigRiskVarName(ulong ticket)
     {
      return StringFormat("EA_%d_OrigRisk_%d", m_magic, ticket);
     }

   void     ModifyPosition(ulong ticket, double new_sl, double tp)
     {
      MqlTradeRequest request;
      MqlTradeResult  result;
      ZeroMemory(request);
      ZeroMemory(result);

      request.action   = TRADE_ACTION_SLTP;
      request.position = ticket;
      request.symbol   = m_symbol;
      request.sl       = new_sl;
      request.tp       = tp;

      if(!OrderSend(request, result) || result.retcode != TRADE_RETCODE_DONE)
        {
         if(m_logger != NULL)
            m_logger.Log(StringFormat("PositionManager: SL/TP modify FAILED ticket=%d retcode=%d", (int)ticket, result.retcode), LOG_WARNING);
        }
     }

public:
            CPositionManager() { m_logger = NULL; }

   bool     Init(string symbol, long magic, double breakeven_rr, double trailing_activate_rr,
                 double trailing_atr_mult, int breakeven_buffer_points, CLogger *logger)
     {
      m_symbol                 = symbol;
      m_magic                  = magic;
      m_breakeven_rr           = breakeven_rr;
      m_trailing_activate_rr   = trailing_activate_rr;
      m_trailing_atr_mult      = trailing_atr_mult;
      m_breakeven_buffer_points = breakeven_buffer_points;
      m_logger                 = logger;
      return true;
     }

   // Called by CEntryExecutor's caller right after a successful fill, so the
   // ORIGINAL SL distance is captured before any breakeven/trailing can alter it.
   void     RegisterOriginalRisk(ulong ticket, double sl_distance_price)
     {
      GlobalVariableSet(OrigRiskVarName(ticket), sl_distance_price);
     }

   void     ManageOpenPositions(double current_atr)
     {
      int total = PositionsTotal();
      for(int i = 0; i < total; i++)
        {
         string sym = PositionGetSymbol(i);
         if(sym != m_symbol) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != m_magic) continue;

         ulong  ticket = (ulong)PositionGetInteger(POSITION_TICKET);
         double entry  = PositionGetDouble(POSITION_PRICE_OPEN);
         double sl     = PositionGetDouble(POSITION_SL);
         double tp     = PositionGetDouble(POSITION_TP);
         long   type   = PositionGetInteger(POSITION_TYPE);
         double point  = SymbolInfoDouble(m_symbol, SYMBOL_POINT);

         double original_risk;
         string var_name = OrigRiskVarName(ticket);
         if(GlobalVariableCheck(var_name))
           {
            original_risk = GlobalVariableGet(var_name);
           }
         else
           {
            // Fallback: shouldn't normally happen. Logged because it means either
            // the position-ticket==deal-ticket assumption didn't hold, or the
            // Global Variable was cleared externally.
            original_risk = MathAbs(entry - sl);
            if(m_logger != NULL)
               m_logger.Log(StringFormat("PositionManager: no persisted original risk for ticket=%d, falling back to live SL distance", (int)ticket), LOG_WARNING);
           }

         if(original_risk <= 0)
            continue; // can't compute R-multiples without a valid risk distance

         double current_price = (type == POSITION_TYPE_BUY) ?
                                 SymbolInfoDouble(m_symbol, SYMBOL_BID) :
                                 SymbolInfoDouble(m_symbol, SYMBOL_ASK);

         double profit_distance = (type == POSITION_TYPE_BUY) ?
                                   (current_price - entry) : (entry - current_price);

         double r_multiple = profit_distance / original_risk;

         //--- Breakeven (one-time move) ---
         bool sl_at_or_past_breakeven = (type == POSITION_TYPE_BUY) ? (sl >= entry - point) : (sl <= entry + point);

         if(!sl_at_or_past_breakeven && r_multiple >= m_breakeven_rr)
           {
            double new_sl = (type == POSITION_TYPE_BUY) ?
                             entry + m_breakeven_buffer_points * point :
                             entry - m_breakeven_buffer_points * point;

            ModifyPosition(ticket, new_sl, tp);
            if(m_logger != NULL)
               m_logger.Log(StringFormat("PositionManager: ticket=%d moved to BREAKEVEN (R=%.2f)", (int)ticket, r_multiple), LOG_TRADE);
            continue; // one management action per tick per position — keeps behaviour simple to audit
           }

         //--- Trailing stop (only after activation R, only ever tightens) ---
         if(r_multiple >= m_trailing_activate_rr && current_atr > 0)
           {
            double trail_distance = current_atr * m_trailing_atr_mult;
            double candidate_sl = (type == POSITION_TYPE_BUY) ?
                                   current_price - trail_distance :
                                   current_price + trail_distance;

            bool improves = (type == POSITION_TYPE_BUY) ? (candidate_sl > sl) : (candidate_sl < sl);

            if(improves)
              {
               ModifyPosition(ticket, candidate_sl, tp);
               if(m_logger != NULL)
                  m_logger.Log(StringFormat("PositionManager: ticket=%d trailing SL -> %.5f (R=%.2f)", (int)ticket, candidate_sl, r_multiple), LOG_INFO);
              }
           }
        }
     }

   // Cleans up the persisted risk value once a position is fully closed.
   // Called from OnTradeTransaction in EA_Main. Prevents unbounded Global
   // Variable growth over the EA's operating lifetime.
   void     CleanupClosedPosition(ulong ticket)
     {
      string var_name = OrigRiskVarName(ticket);
      if(GlobalVariableCheck(var_name))
         GlobalVariableDel(var_name);
     }
  };

#endif // __POSITIONMANAGER_MQH__
