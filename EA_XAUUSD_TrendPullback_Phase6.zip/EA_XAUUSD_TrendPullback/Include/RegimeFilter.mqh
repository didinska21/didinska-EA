//+------------------------------------------------------------------+
//| RegimeFilter.mqh                                                 |
//| Determines whether the higher-timeframe regime is "trending"     |
//| using persistent ADX + EMA slope.                                |
//|                                                                   |
//| DESIGN NOTE (anti-repainting): all indicator reads start at      |
//| shift 1 (last CLOSED bar), never shift 0 (the currently forming  |
//| bar). This guarantees the same value is seen in backtest and     |
//| live once a given bar has closed, and prevents the filter from   |
//| "flip-flopping" as a live bar forms.                             |
//+------------------------------------------------------------------+
#ifndef __REGIMEFILTER_MQH__
#define __REGIMEFILTER_MQH__

#include "..\Include\Enums.mqh"
#include "..\Include\Logger.mqh"

class CRegimeFilter
  {
private:
   int               m_adx_handle;
   int               m_ema_handle;
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   double            m_adx_threshold;
   int               m_adx_persist_bars;
   int               m_slope_bars;
   CLogger          *m_logger;

public:
                     CRegimeFilter()
     {
      m_adx_handle = INVALID_HANDLE;
      m_ema_handle = INVALID_HANDLE;
      m_logger     = NULL;
     }

   bool              Init(string symbol, ENUM_TIMEFRAMES tf, int adx_period, double adx_threshold,
                           int adx_persist_bars, int ema_period, int slope_bars, CLogger *logger)
     {
      m_symbol           = symbol;
      m_tf               = tf;
      m_adx_threshold    = adx_threshold;
      m_adx_persist_bars = adx_persist_bars;
      m_slope_bars       = slope_bars;
      m_logger           = logger;

      m_adx_handle = iADX(m_symbol, m_tf, adx_period);
      m_ema_handle = iMA(m_symbol, m_tf, ema_period, 0, MODE_EMA, PRICE_CLOSE);

      if(m_adx_handle == INVALID_HANDLE || m_ema_handle == INVALID_HANDLE)
        {
         if(m_logger != NULL)
            m_logger.Log("RegimeFilter: failed to create indicator handles, error=" + IntegerToString(GetLastError()), LOG_ERROR);
         return false;
        }
      return true;
     }

   // Returns true if a persistent trend is present; fills 'direction'.
   bool              IsTrendValid(ENUM_TREND_DIRECTION &direction)
     {
      direction = TREND_NONE;

      //--- ADX persistence check (must hold above threshold for N closed bars)
      double adx_buf[];
      ArraySetAsSeries(adx_buf, true);
      if(CopyBuffer(m_adx_handle, 0, 1, m_adx_persist_bars, adx_buf) < m_adx_persist_bars)
        {
         if(m_logger != NULL)
            m_logger.Log("RegimeFilter: insufficient ADX history", LOG_WARNING);
         return false;
        }

      for(int i = 0; i < m_adx_persist_bars; i++)
        {
         if(adx_buf[i] < m_adx_threshold)
            return false; // whipsaw guard: one strong bar is not enough
        }

      //--- EMA slope check, comparing last closed bar to N bars before it
      double ema_buf[];
      ArraySetAsSeries(ema_buf, true);
      int ema_needed = m_slope_bars + 1;
      if(CopyBuffer(m_ema_handle, 0, 1, ema_needed, ema_buf) < ema_needed)
        {
         if(m_logger != NULL)
            m_logger.Log("RegimeFilter: insufficient EMA history", LOG_WARNING);
         return false;
        }

      double ema_recent = ema_buf[0];            // last closed bar
      double ema_past   = ema_buf[m_slope_bars];  // m_slope_bars before that

      if(ema_recent > ema_past)
         direction = TREND_UP;
      else if(ema_recent < ema_past)
         direction = TREND_DOWN;
      else
         return false;

      return true;
     }

   void              Release()
     {
      if(m_adx_handle != INVALID_HANDLE) IndicatorRelease(m_adx_handle);
      if(m_ema_handle != INVALID_HANDLE) IndicatorRelease(m_ema_handle);
     }
  };

#endif // __REGIMEFILTER_MQH__
