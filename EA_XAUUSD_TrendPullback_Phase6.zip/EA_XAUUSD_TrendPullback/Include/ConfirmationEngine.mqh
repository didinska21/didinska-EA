//+------------------------------------------------------------------+
//| ConfirmationEngine.mqh                                           |
//| Confirms a pullback setup via:                                   |
//|   1) Rejection candle in the trend direction                     |
//|   2) Minimum body-to-range ratio (filters false-breakout noise,  |
//|      added during Phase 3 adversarial review)                    |
//|   3) RSI momentum turning in the trend direction                 |
//|                                                                   |
//| DESIGN NOTE: all reads use shift 1 (last CLOSED candle) so the   |
//| decision is made once, right after the bar closes, and never     |
//| changes retroactively (no repainting).                           |
//+------------------------------------------------------------------+
#ifndef __CONFIRMATIONENGINE_MQH__
#define __CONFIRMATIONENGINE_MQH__

#include "..\Include\Enums.mqh"
#include "..\Include\Logger.mqh"

class CConfirmationEngine
  {
private:
   int               m_rsi_handle;
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   double            m_rsi_oversold;
   double            m_rsi_overbought;
   double            m_min_body_ratio;
   CLogger          *m_logger;

   bool              IsBodyRatioValid(int shift)
     {
      double open  = iOpen(m_symbol, m_tf, shift);
      double close = iClose(m_symbol, m_tf, shift);
      double high  = iHigh(m_symbol, m_tf, shift);
      double low   = iLow(m_symbol, m_tf, shift);

      double range = high - low;
      if(range <= 0)
         return false;

      double ratio = MathAbs(close - open) / range;
      return (ratio >= m_min_body_ratio);
     }

   bool              IsRejectionCandle(ENUM_TREND_DIRECTION direction, int shift)
     {
      if(!IsBodyRatioValid(shift))
         return false;

      double open  = iOpen(m_symbol, m_tf, shift);
      double close = iClose(m_symbol, m_tf, shift);

      if(direction == TREND_UP)
         return (close > open); // bullish rejection candle
      if(direction == TREND_DOWN)
         return (close < open); // bearish rejection candle

      return false;
     }

   bool              IsRSIConfirmed(ENUM_TREND_DIRECTION direction)
     {
      double rsi_buf[];
      ArraySetAsSeries(rsi_buf, true);
      // index 0 = shift0 (forming bar, unused), 1 = last closed, 2 = bar before that
      if(CopyBuffer(m_rsi_handle, 0, 0, 3, rsi_buf) < 3)
         return false;

      double rsi_current  = rsi_buf[1];
      double rsi_previous = rsi_buf[2];

      if(direction == TREND_UP)
         return (rsi_current > m_rsi_oversold && rsi_current > rsi_previous);
      if(direction == TREND_DOWN)
         return (rsi_current < m_rsi_overbought && rsi_current < rsi_previous);

      return false;
     }

public:
                     CConfirmationEngine()
     {
      m_rsi_handle = INVALID_HANDLE;
      m_logger     = NULL;
     }

   bool              Init(string symbol, ENUM_TIMEFRAMES tf, int rsi_period, double rsi_oversold,
                           double rsi_overbought, double min_body_ratio, CLogger *logger)
     {
      m_symbol         = symbol;
      m_tf             = tf;
      m_rsi_oversold   = rsi_oversold;
      m_rsi_overbought = rsi_overbought;
      m_min_body_ratio = min_body_ratio;
      m_logger         = logger;

      m_rsi_handle = iRSI(m_symbol, m_tf, rsi_period, PRICE_CLOSE);
      if(m_rsi_handle == INVALID_HANDLE)
        {
         if(m_logger != NULL)
            m_logger.Log("ConfirmationEngine: failed to create RSI handle, error=" + IntegerToString(GetLastError()), LOG_ERROR);
         return false;
        }
      return true;
     }

   bool              IsConfirmed(ENUM_TREND_DIRECTION direction)
     {
      return (IsRejectionCandle(direction, 1) && IsRSIConfirmed(direction));
     }

   void              Release()
     {
      if(m_rsi_handle != INVALID_HANDLE) IndicatorRelease(m_rsi_handle);
     }
  };

#endif // __CONFIRMATIONENGINE_MQH__
