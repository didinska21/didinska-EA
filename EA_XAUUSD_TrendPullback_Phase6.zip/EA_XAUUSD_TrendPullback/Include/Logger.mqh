//+------------------------------------------------------------------+
//| Logger.mqh                                                       |
//| Every trading decision must be traceable (project requirement).  |
//| Writes to both the Experts tab and a persistent log file.        |
//+------------------------------------------------------------------+
#ifndef __LOGGER_MQH__
#define __LOGGER_MQH__

#include "..\Include\Enums.mqh"

class CLogger
  {
private:
   int      m_file_handle;
   bool     m_file_enabled;

   string   LevelToString(ENUM_LOG_LEVEL level)
     {
      switch(level)
        {
         case LOG_INFO:      return "INFO";
         case LOG_WARNING:   return "WARNING";
         case LOG_ERROR:     return "ERROR";
         case LOG_TRADE:     return "TRADE";
         case LOG_EMERGENCY: return "EMERGENCY";
        }
      return "UNKNOWN";
     }

public:
            CLogger() { m_file_handle = INVALID_HANDLE; m_file_enabled = false; }

   bool     Init(string filename, bool enable_file)
     {
      m_file_enabled = enable_file;
      if(!m_file_enabled)
         return true;

      m_file_handle = FileOpen(filename, FILE_WRITE|FILE_READ|FILE_TXT|FILE_ANSI|FILE_SHARE_READ);
      if(m_file_handle == INVALID_HANDLE)
        {
         Print("CLogger: Failed to open log file, error=", GetLastError());
         m_file_enabled = false;
         return false;
        }
      FileSeek(m_file_handle, 0, SEEK_END); // append, never overwrite prior run's log
      return true;
     }

   void     Log(string message, ENUM_LOG_LEVEL level = LOG_INFO)
     {
      string line = StringFormat("[%s] [%s] %s",
                     TimeToString(TimeCurrent(), TIME_DATE|TIME_SECONDS),
                     LevelToString(level), message);

      Print(line);

      if(m_file_enabled && m_file_handle != INVALID_HANDLE)
        {
         FileWriteString(m_file_handle, line + "\r\n");
         FileFlush(m_file_handle);
        }
     }

   void     Deinit()
     {
      if(m_file_handle != INVALID_HANDLE)
        {
         FileClose(m_file_handle);
         m_file_handle = INVALID_HANDLE;
        }
     }
  };

#endif // __LOGGER_MQH__
