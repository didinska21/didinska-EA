//+------------------------------------------------------------------+
//| EntryExecutor.mqh                                                |
//| Sends market orders with:                                        |
//|  - Broker-appropriate filling mode detection (FOK/IOC/Return)    |
//|  - Slippage protection via request.deviation                    |
//|  - Bounded retry on requote / price-changed / off-quotes only    |
//|    (non-retryable errors fail immediately — no infinite retry)   |
//|  - Partial-fill detection and logging (remaining volume is NOT   |
//|    auto re-sent; flagged for manual review — re-sending blindly  |
//|    can compound into unintended position size in fast markets)   |
//+------------------------------------------------------------------+
#ifndef __ENTRYEXECUTOR_MQH__
#define __ENTRYEXECUTOR_MQH__

#include "..\Include\Enums.mqh"
#include "..\Include\Logger.mqh"

class CEntryExecutor
  {
private:
   string   m_symbol;
   long     m_magic;
   int      m_max_slippage_points;
   int      m_max_retries;
   CLogger *m_logger;

   ENUM_ORDER_TYPE_FILLING GetSupportedFilling()
     {
      int filling_mode = (int)SymbolInfoInteger(m_symbol, SYMBOL_FILLING_MODE);
      if((filling_mode & SYMBOL_FILLING_FOK) != 0) return ORDER_FILLING_FOK;
      if((filling_mode & SYMBOL_FILLING_IOC) != 0) return ORDER_FILLING_IOC;
      return ORDER_FILLING_RETURN; // fallback for brokers requiring Return on market orders
     }

public:
            CEntryExecutor() { m_logger = NULL; }

   bool     Init(string symbol, long magic, int max_slippage_points, int max_retries, CLogger *logger)
     {
      m_symbol              = symbol;
      m_magic               = magic;
      m_max_slippage_points = max_slippage_points;
      m_max_retries         = max_retries;
      m_logger              = logger;
      return true;
     }

   // result_position_ticket: on success, the ticket to use for position lookups
   // afterward. Assumes standard MT5 behaviour where the position ticket equals
   // the ticket of the deal that opened it — CPositionManager falls back
   // gracefully (with a logged warning) if that assumption ever doesn't hold.
   bool     ExecuteEntry(ENUM_TREND_DIRECTION direction, double lot, double sl_price, double tp_price,
                          ulong &result_position_ticket)
     {
      result_position_ticket = 0;

      if(direction == TREND_NONE || lot <= 0)
        {
         if(m_logger != NULL)
            m_logger.Log("EntryExecutor: invalid direction or lot, aborting", LOG_ERROR);
         return false;
        }

      for(int attempt = 1; attempt <= m_max_retries; attempt++)
        {
         MqlTick tick;
         if(!SymbolInfoTick(m_symbol, tick))
           {
            if(m_logger != NULL)
               m_logger.Log("EntryExecutor: failed to get current tick", LOG_ERROR);
            return false;
           }

         MqlTradeRequest request;
         MqlTradeResult  result;
         ZeroMemory(request);
         ZeroMemory(result);

         request.action       = TRADE_ACTION_DEAL;
         request.symbol       = m_symbol;
         request.volume       = lot;
         request.magic        = m_magic;
         request.deviation    = m_max_slippage_points;
         request.type_filling = GetSupportedFilling();
         request.sl           = sl_price;
         request.tp           = tp_price;
         request.comment      = "TrendPullback";

         if(direction == TREND_UP)
           {
            request.type  = ORDER_TYPE_BUY;
            request.price = tick.ask;
           }
         else
           {
            request.type  = ORDER_TYPE_SELL;
            request.price = tick.bid;
           }

         bool sent = OrderSend(request, result);

         if(sent && (result.retcode == TRADE_RETCODE_DONE || result.retcode == TRADE_RETCODE_DONE_PARTIAL))
           {
            result_position_ticket = result.deal; // position ticket == opening deal ticket (see note above)

            if(result.retcode == TRADE_RETCODE_DONE_PARTIAL || result.volume < lot)
              {
               if(m_logger != NULL)
                  m_logger.Log(StringFormat(
                     "EntryExecutor: PARTIAL FILL — requested=%.2f filled=%.2f. Remaining volume NOT auto re-sent (manual review).",
                     lot, result.volume), LOG_WARNING);
              }
            else
              {
               if(m_logger != NULL)
                  m_logger.Log(StringFormat(
                     "EntryExecutor: order filled. deal=%d lot=%.2f price=%.5f sl=%.5f tp=%.5f",
                     (int)result.deal, lot, result.price, sl_price, tp_price), LOG_TRADE);
              }
            return true;
           }

         if(result.retcode == TRADE_RETCODE_REQUOTE ||
            result.retcode == TRADE_RETCODE_PRICE_CHANGED ||
            result.retcode == TRADE_RETCODE_PRICE_OFF)
           {
            if(m_logger != NULL)
               m_logger.Log(StringFormat("EntryExecutor: retryable retcode=%d on attempt %d/%d, retrying with fresh price...",
                            result.retcode, attempt, m_max_retries), LOG_WARNING);
            continue;
           }

         if(m_logger != NULL)
            m_logger.Log(StringFormat("EntryExecutor: order FAILED, retcode=%d comment=%s. Not retrying (non-retryable).",
                         result.retcode, result.comment), LOG_ERROR);
         return false;
        }

      if(m_logger != NULL)
         m_logger.Log(StringFormat("EntryExecutor: exhausted %d retries without a fill.", m_max_retries), LOG_ERROR);
      return false;
     }
  };

#endif // __ENTRYEXECUTOR_MQH__
