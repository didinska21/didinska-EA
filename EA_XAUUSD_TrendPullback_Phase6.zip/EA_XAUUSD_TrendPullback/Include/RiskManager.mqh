//+------------------------------------------------------------------+
//| RiskManager.mqh                                                  |
//| Central risk gate. Nothing in this EA should ever open or size   |
//| a trade without going through this module first.                 |
//|                                                                   |
//| SCOPING DECISIONS (documented per project change-control rules): |
//|  - Daily loss, weekly loss, and max drawdown are ACCOUNT-WIDE.    |
//|    Capital protection must apply regardless of which strategy    |
//|    or manual action caused the drawdown.                         |
//|  - Consecutive-loss count and open-position count are scoped to  |
//|    THIS EA's magic number + symbol, so another EA or manual      |
//|    trading on the same account doesn't corrupt this EA's own     |
//|    behavioural statistics.                                       |
//|  - Peak equity (for drawdown %) is persisted via a terminal      |
//|    Global Variable, so it survives EA reload, terminal restart,  |
//|    and VPS restart (per project's restart-resilience             |
//|    requirement).                                                 |
//|  - If the risk-based lot size rounds below the broker's minimum  |
//|    lot, the trade is SKIPPED rather than rounded up — rounding    |
//|    up would silently exceed the configured risk %.                |
//+------------------------------------------------------------------+
#ifndef __RISKMANAGER_MQH__
#define __RISKMANAGER_MQH__

#include "..\Include\Enums.mqh"
#include "..\Include\Logger.mqh"

class CRiskManager
  {
private:
   string   m_symbol;
   long     m_magic;
   double   m_risk_percent;
   double   m_max_daily_loss_pct;
   double   m_max_weekly_loss_pct;
   double   m_max_drawdown_pct;
   int      m_max_consec_losses;
   int      m_max_open_positions;
   double   m_max_lot_cap;
   int      m_max_spread_points;
   CLogger *m_logger;

   //--- time helpers ---
   datetime GetDayStart(datetime t)
     {
      MqlDateTime dt;
      TimeToStruct(t, dt);
      dt.hour = 0; dt.min = 0; dt.sec = 0;
      return StructToTime(dt);
     }

   datetime GetWeekStart(datetime t)
     {
      MqlDateTime dt;
      TimeToStruct(t, dt);
      dt.hour = 0; dt.min = 0; dt.sec = 0;
      datetime day_start = StructToTime(dt);
      return day_start - (datetime)(dt.day_of_week * 86400);
     }

   string PeakEquityVarName()
     {
      return StringFormat("EA_%s_%d_PeakEquity", m_symbol, m_magic);
     }

   //--- realized P/L since a given time, optionally scoped to this EA's magic number ---
   double GetRealizedPnLSince(datetime since, bool scope_to_magic)
     {
      double total = 0.0;
      if(!HistorySelect(since, TimeCurrent()))
         return 0.0;

      int deals = HistoryDealsTotal();
      for(int i = 0; i < deals; i++)
        {
         ulong ticket = HistoryDealGetTicket(i);
         if(ticket == 0) continue;

         if(scope_to_magic && (long)HistoryDealGetInteger(ticket, DEAL_MAGIC) != m_magic)
            continue;

         long entry = HistoryDealGetInteger(ticket, DEAL_ENTRY);
         if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_INOUT)
            continue; // only closing deals count as realized P/L

         total += HistoryDealGetDouble(ticket, DEAL_PROFIT)
                + HistoryDealGetDouble(ticket, DEAL_SWAP)
                + HistoryDealGetDouble(ticket, DEAL_COMMISSION);
        }
      return total;
     }

   void UpdatePeakEquity()
     {
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);
      double peak = GlobalVariableCheck(PeakEquityVarName()) ? GlobalVariableGet(PeakEquityVarName()) : 0.0;
      if(equity > peak)
         GlobalVariableSet(PeakEquityVarName(), equity);
     }

   //--- individual checks ---
   bool CheckSpread(string &reason)
     {
      long spread_points = SymbolInfoInteger(m_symbol, SYMBOL_SPREAD);
      if(spread_points > m_max_spread_points)
        {
         reason = StringFormat("Spread too wide: %d pts > %d pts", (int)spread_points, m_max_spread_points);
         return false;
        }
      return true;
     }

   bool CheckMaxOpenPositions(string &reason)
     {
      int count = 0;
      int total = PositionsTotal();
      for(int i = 0; i < total; i++)
        {
         string sym = PositionGetSymbol(i);
         if(sym != m_symbol) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != m_magic) continue;
         count++;
        }

      if(count >= m_max_open_positions)
        {
         reason = StringFormat("Max open positions reached: %d >= %d", count, m_max_open_positions);
         return false;
        }
      return true;
     }

   bool CheckDailyLoss(string &reason)
     {
      datetime day_start = GetDayStart(TimeCurrent());
      double realized_today = GetRealizedPnLSince(day_start, false); // account-wide
      double balance = AccountInfoDouble(ACCOUNT_BALANCE);
      double day_start_balance = balance - realized_today; // approx: ignores intraday deposits/withdrawals
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);

      if(day_start_balance <= 0)
         return true; // guard against division by zero on a fresh/empty account

      double loss_pct = (day_start_balance - equity) / day_start_balance * 100.0;

      if(loss_pct >= m_max_daily_loss_pct)
        {
         reason = StringFormat("Daily loss limit hit: %.2f%% >= %.2f%%", loss_pct, m_max_daily_loss_pct);
         return false;
        }
      return true;
     }

   bool CheckWeeklyLoss(string &reason)
     {
      datetime week_start = GetWeekStart(TimeCurrent());
      double realized_week = GetRealizedPnLSince(week_start, false); // account-wide
      double balance = AccountInfoDouble(ACCOUNT_BALANCE);
      double week_start_balance = balance - realized_week;
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);

      if(week_start_balance <= 0)
         return true;

      double loss_pct = (week_start_balance - equity) / week_start_balance * 100.0;

      if(loss_pct >= m_max_weekly_loss_pct)
        {
         reason = StringFormat("Weekly loss limit hit: %.2f%% >= %.2f%%", loss_pct, m_max_weekly_loss_pct);
         return false;
        }
      return true;
     }

   bool CheckMaxDrawdown(string &reason)
     {
      UpdatePeakEquity();
      double peak = GlobalVariableGet(PeakEquityVarName());
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);

      if(peak <= 0)
         return true;

      double dd_pct = (peak - equity) / peak * 100.0;

      if(dd_pct >= m_max_drawdown_pct)
        {
         reason = StringFormat("Max drawdown hit: %.2f%% >= %.2f%% (peak equity=%.2f)", dd_pct, m_max_drawdown_pct, peak);
         return false;
        }
      return true;
     }

   bool CheckConsecutiveLosses(string &reason)
     {
      // Bounded lookback window (30 days) to keep this cheap; if the EA hasn't
      // traded in 30 days, a "reset" of the streak is the correct behaviour anyway.
      datetime lookback_start = TimeCurrent() - 30 * 86400;
      if(!HistorySelect(lookback_start, TimeCurrent()))
         return true;

      int deals = HistoryDealsTotal();
      int consecutive = 0;

      for(int i = deals - 1; i >= 0; i--)
        {
         ulong ticket = HistoryDealGetTicket(i);
         if(ticket == 0) continue;

         if((long)HistoryDealGetInteger(ticket, DEAL_MAGIC) != m_magic)
            continue; // scope to this EA only

         long entry = HistoryDealGetInteger(ticket, DEAL_ENTRY);
         if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_INOUT)
            continue;

         double pnl = HistoryDealGetDouble(ticket, DEAL_PROFIT)
                    + HistoryDealGetDouble(ticket, DEAL_SWAP)
                    + HistoryDealGetDouble(ticket, DEAL_COMMISSION);

         if(pnl < 0)
           {
            consecutive++;
            if(consecutive >= m_max_consec_losses)
              {
               reason = StringFormat("Consecutive losses limit hit: %d >= %d (manual review required)", consecutive, m_max_consec_losses);
               return false;
              }
           }
         else
           {
            break; // streak broken by a win/breakeven — stop scanning further back
           }
        }
      return true;
     }

public:
            CRiskManager() { m_logger = NULL; }

   bool     Init(string symbol, long magic, double risk_percent, double max_daily_loss_pct,
                 double max_weekly_loss_pct, double max_drawdown_pct, int max_consec_losses,
                 int max_open_positions, double max_lot_cap, int max_spread_points, CLogger *logger)
     {
      m_symbol              = symbol;
      m_magic               = magic;
      m_risk_percent        = risk_percent;
      m_max_daily_loss_pct  = max_daily_loss_pct;
      m_max_weekly_loss_pct = max_weekly_loss_pct;
      m_max_drawdown_pct    = max_drawdown_pct;
      m_max_consec_losses   = max_consec_losses;
      m_max_open_positions  = max_open_positions;
      m_max_lot_cap         = max_lot_cap;
      m_max_spread_points   = max_spread_points;
      m_logger              = logger;

      UpdatePeakEquity(); // seed peak equity on init so drawdown has a valid baseline
      return true;
     }

   // Aggregated gate. ALL trade decisions must check this first.
   bool     IsTradingAllowed(string &reason)
     {
      if(!CheckSpread(reason))            return false;
      if(!CheckMaxOpenPositions(reason))  return false;
      if(!CheckDailyLoss(reason))         return false;
      if(!CheckWeeklyLoss(reason))        return false;
      if(!CheckMaxDrawdown(reason))       return false;
      if(!CheckConsecutiveLosses(reason)) return false;
      return true;
     }

   // Risk Amount = Equity x Risk% ; Lot = Risk Amount / Monetary Risk per Lot
   // sl_distance_price: the SL distance expressed in price units (not points/pips).
   double   CalculateLotSize(double sl_distance_price, string &reason_if_invalid)
     {
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);
      double risk_amount = equity * (m_risk_percent / 100.0);

      double tick_value = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_VALUE);
      double tick_size  = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_SIZE);

      if(tick_size <= 0 || tick_value <= 0 || sl_distance_price <= 0)
        {
         reason_if_invalid = "Invalid tick data or SL distance for lot calculation";
         return 0.0;
        }

      double monetary_risk_per_lot = (sl_distance_price / tick_size) * tick_value;
      if(monetary_risk_per_lot <= 0)
        {
         reason_if_invalid = "Computed monetary risk per lot is zero/negative";
         return 0.0;
        }

      double raw_lot = risk_amount / monetary_risk_per_lot;

      double lot_step       = SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_STEP);
      double min_lot        = SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_MIN);
      double max_lot_broker = SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_MAX);
      double max_lot_effective = MathMin(max_lot_broker, m_max_lot_cap);

      double lot = (lot_step > 0) ? MathFloor(raw_lot / lot_step) * lot_step : raw_lot;

      if(lot < min_lot)
        {
         reason_if_invalid = StringFormat(
            "Calculated lot %.4f is below broker minimum %.2f for this risk%%/SL-distance combo — "
            "trade SKIPPED rather than rounded up (rounding up would exceed configured risk)",
            raw_lot, min_lot);
         return 0.0;
        }

      if(lot > max_lot_effective)
         lot = max_lot_effective; // hard cap, never silently exceed configured ceiling

      return lot;
     }
  };

#endif // __RISKMANAGER_MQH__
