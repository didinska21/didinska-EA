//+------------------------------------------------------------------+
//| Enums.mqh                                                        |
//| Shared enumerations for EA_XAUUSD_TrendPullback                  |
//+------------------------------------------------------------------+
#ifndef __ENUMS_MQH__
#define __ENUMS_MQH__

// High-level EA state machine (see Phase 3 architecture spec)
enum ENUM_EA_STATE
  {
   STATE_IDLE,                  // No valid regime, EA idle
   STATE_SCANNING_FOR_SETUP,    // Regime valid, waiting for pullback
   STATE_WAITING_CONFIRMATION,  // Pullback detected, waiting for confirmation
   STATE_ENTRY_TRIGGERED,       // Confirmed signal (execution wired in Phase 5/6)
   STATE_IN_POSITION,           // Position open (Phase 6/7 scope)
   STATE_EMERGENCY_STOP         // Hard stop, no trading allowed (Phase 5 scope)
  };

// Trend direction as determined by CRegimeFilter
enum ENUM_TREND_DIRECTION
  {
   TREND_NONE,
   TREND_UP,
   TREND_DOWN
  };

// Log severity levels used by CLogger
enum ENUM_LOG_LEVEL
  {
   LOG_INFO,
   LOG_WARNING,
   LOG_ERROR,
   LOG_TRADE,
   LOG_EMERGENCY
  };

#endif // __ENUMS_MQH__
