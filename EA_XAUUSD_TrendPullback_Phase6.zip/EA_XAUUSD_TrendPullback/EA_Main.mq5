//+------------------------------------------------------------------+
//| EA_Main.mq5                                                      |
//| EA_XAUUSD_TrendPullback                                          |
//|                                                                   |
//| PHASE 6 SCOPE (per project development plan):                   |
//|   - Regime Filter, Setup Detector, Confirmation Engine (Phase 4) |
//|   - Risk Manager gating + lot sizing (Phase 5)                   |
//|   - NEW: SL/TP Calculator, Entry Executor, Position Manager       |
//|                                                                   |
//| *** THIS BUILD CAN PLACE REAL ORDERS. ***                        |
//| Unlike Phase 4/5 builds, this EA is no longer signal-detection    |
//| only — CEntryExecutor.ExecuteEntry() is now actually called.      |
//| Per the project's own phase order, the MANDATORY next steps       |
//| before any live use are:                                          |
//|   Phase 7  — Backtesting (in-sample + out-of-sample)              |
//|   Phase 9  — Robustness / stress testing                          |
//|   Phase 11 — Forward testing on a DEMO account                    |
//| Do not attach this to a live account before those phases pass.    |
//| Attach to Strategy Tester or a DEMO account first.                |
//+------------------------------------------------------------------+
#property copyright "Internal project build - Phase 6"
#property version   "1.20"

#include "Config\InputParameters.mqh"
#include "Include\Enums.mqh"
#include "Include\Logger.mqh"
#include "Include\RegimeFilter.mqh"
#include "Include\SetupDetector.mqh"
#include "Include\ConfirmationEngine.mqh"
#include "Include\RiskManager.mqh"
#include "Include\SLTPCalculator.mqh"
#include "Include\EntryExecutor.mqh"
#include "Include\PositionManager.mqh"

CLogger              g_logger;
CRegimeFilter        g_regime;
CSetupDetector       g_setup;
CConfirmationEngine  g_confirm;
CRiskManager         g_risk;
CSLTPCalculator      g_sltp;
CEntryExecutor       g_executor;
CPositionManager     g_posManager;

ENUM_EA_STATE        g_state;
datetime             g_last_bar_time;

//+------------------------------------------------------------------+
int OnInit()
  {
   g_state         = STATE_IDLE;
   g_last_bar_time = 0;

   string log_filename = StringFormat("EA_XAUUSD_TrendPullback_%s.log", _Symbol);
   g_logger.Init(log_filename, InpEnableFileLog);
   g_logger.Log("=== EA Initialized | PHASE 6 BUILD: REAL ORDER EXECUTION ENABLED — test on Strategy Tester / DEMO first ===", LOG_WARNING);

   if(!g_regime.Init(_Symbol, InpRegimeTF, InpADX_Period, InpADX_Threshold,
                      InpADX_PersistBars, InpEMA_TrendPeriod, InpEMA_SlopeBars, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: RegimeFilter", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_setup.Init(_Symbol, InpSetupTF, InpEMA_PullbackPeriod, InpATR_Period,
                     InpATR_ToleranceMult, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: SetupDetector", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_confirm.Init(_Symbol, InpSetupTF, InpRSI_Period, InpRSI_OversoldLvl,
                       InpRSI_OverboughtLvl, InpMinBodyRatio, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: ConfirmationEngine", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_risk.Init(_Symbol, InpMagicNumber, InpRiskPercent, InpMaxDailyLossPct,
                    InpMaxWeeklyLossPct, InpMaxDrawdownPct, InpMaxConsecLosses,
                    InpMaxOpenPositions, InpMaxLotCap, InpMaxSpreadPoints, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: RiskManager", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_sltp.Init(_Symbol, InpSetupTF, InpSwingLookbackBars, InpSL_BufferATRMult, InpMinRR, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: SLTPCalculator", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_executor.Init(_Symbol, InpMagicNumber, InpMaxSlippagePoints, InpMaxRetries, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: EntryExecutor", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_posManager.Init(_Symbol, InpMagicNumber, InpBreakEvenRR, InpTrailingActivateRR,
                          InpTrailingATRMult, InpBreakEvenBufferPts, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: PositionManager", LOG_ERROR);
      return INIT_FAILED;
     }

   g_logger.Log("All Phase 4+5+6 modules initialized successfully.", LOG_INFO);
   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_logger.Log("EA Deinitialized. Reason code=" + IntegerToString(reason), LOG_INFO);
   g_regime.Release();
   g_setup.Release();
   g_confirm.Release();
   g_logger.Deinit();
  }

//+------------------------------------------------------------------+
// Evaluates once per closed bar on the setup timeframe (H1 default).
// Prevents re-evaluating the same signal multiple times per bar and
// keeps every decision anchored to closed-bar data (see module notes).
bool IsNewBar()
  {
   datetime current_bar_time = iTime(_Symbol, InpSetupTF, 0);
   if(current_bar_time != g_last_bar_time)
     {
      g_last_bar_time = current_bar_time;
      return true;
     }
   return false;
  }

//+------------------------------------------------------------------+
// No-trade window: last stretch before weekend close. Weekend gaps and
// thin Friday-evening liquidity were flagged during the Phase 3
// adversarial review as an unhandled risk; this closes that gap.
bool IsFridayCloseWindow()
  {
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   // day_of_week: 0=Sunday..6=Saturday
   return (dt.day_of_week == 5 && dt.hour >= InpFridayCloseHour);
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   // Position management reacts to live price every tick — protecting an
   // open position should not wait for a bar close, unlike signal detection.
   g_posManager.ManageOpenPositions(g_setup.GetCurrentATR());

   if(!IsNewBar())
      return;

   RunStateMachine();
  }

//+------------------------------------------------------------------+
void RunStateMachine()
  {
   ENUM_TREND_DIRECTION direction;

//--- Step 1: Regime Filter
   if(!g_regime.IsTrendValid(direction))
     {
      if(g_state != STATE_IDLE && InpVerboseLog)
         g_logger.Log("Regime invalid -> back to IDLE", LOG_INFO);
      g_state = STATE_IDLE;
      return;
     }

   g_state = STATE_SCANNING_FOR_SETUP;

//--- Step 2: Setup Detector
   double ema_value, atr_value;
   if(!g_setup.IsPullbackPresent(ema_value, atr_value))
      return; // trending, but no pullback into the zone yet

   g_state = STATE_WAITING_CONFIRMATION;
   g_logger.Log(StringFormat("Setup detected | direction=%s EMA=%.2f ATR=%.2f",
                EnumToString(direction), ema_value, atr_value), LOG_INFO);

//--- Step 3: Confirmation Engine
   if(!g_confirm.IsConfirmed(direction))
      return; // pullback present, confirmation not yet met

   g_state = STATE_ENTRY_TRIGGERED;
   g_logger.Log(StringFormat("*** SIGNAL CONFIRMED *** direction=%s EMA=%.2f ATR=%.2f",
                EnumToString(direction), ema_value, atr_value), LOG_TRADE);

//--- Step 4: No-trade window (Friday close guard)
   if(IsFridayCloseWindow())
     {
      g_logger.Log("Signal REJECTED: inside Friday pre-close no-trade window", LOG_INFO);
      g_state = STATE_IDLE;
      return;
     }

//--- Step 5: Risk Manager gate
   string block_reason;
   if(!g_risk.IsTradingAllowed(block_reason))
     {
      g_logger.Log("Signal REJECTED by risk manager: " + block_reason, LOG_WARNING);
      g_state = STATE_IDLE;
      return;
     }

//--- Step 6: SL/TP Calculation (objective, deterministic — see SLTPCalculator.mqh)
   double entry_price = (direction == TREND_UP) ?
                         SymbolInfoDouble(_Symbol, SYMBOL_ASK) :
                         SymbolInfoDouble(_Symbol, SYMBOL_BID);

   double sl_price, tp_price;
   string sltp_error;
   if(!g_sltp.Calculate(direction, atr_value, entry_price, sl_price, tp_price, sltp_error))
     {
      g_logger.Log("Signal REJECTED by SL/TP calculator: " + sltp_error, LOG_WARNING);
      g_state = STATE_IDLE;
      return;
     }

   double sl_distance = MathAbs(entry_price - sl_price);

//--- Step 7: Lot sizing from real SL distance
   string lot_error;
   double lot = g_risk.CalculateLotSize(sl_distance, lot_error);
   if(lot <= 0.0)
     {
      g_logger.Log("Signal REJECTED: lot calculation returned 0: " + lot_error, LOG_WARNING);
      g_state = STATE_IDLE;
      return;
     }

//--- Step 8: Execution
   ulong position_ticket;
   if(!g_executor.ExecuteEntry(direction, lot, sl_price, tp_price, position_ticket))
     {
      g_logger.Log("Entry execution FAILED — see EntryExecutor log line above for retcode detail", LOG_ERROR);
      g_state = STATE_IDLE;
      return;
     }

   // Persist the ORIGINAL SL distance for this position so PositionManager's
   // R-multiple math stays correct even after SL is later moved to breakeven.
   g_posManager.RegisterOriginalRisk(position_ticket, sl_distance);

   g_state = STATE_IN_POSITION;
  }

//+------------------------------------------------------------------+
// Cleans up the persisted "original risk" Global Variable once a position
// tied to this EA's magic number is fully closed, preventing unbounded
// Global Variable growth over the EA's operating lifetime.
void OnTradeTransaction(const MqlTradeTransaction &trans,
                         const MqlTradeRequest &request,
                         const MqlTradeResult &result)
  {
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD)
      return;

   if(!HistoryDealSelect(trans.deal))
      return;

   if((long)HistoryDealGetInteger(trans.deal, DEAL_MAGIC) != InpMagicNumber)
      return;

   long entry_type = HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   if(entry_type != DEAL_ENTRY_OUT && entry_type != DEAL_ENTRY_INOUT)
      return; // only clean up on closing deals

   ulong position_id = (ulong)HistoryDealGetInteger(trans.deal, DEAL_POSITION_ID);
   g_posManager.CleanupClosedPosition(position_id);

   double deal_profit = HistoryDealGetDouble(trans.deal, DEAL_PROFIT);
   g_logger.Log(StringFormat("Position closed | position_id=%d profit=%.2f", (int)position_id, deal_profit), LOG_TRADE);
  }
//+------------------------------------------------------------------+
