//+------------------------------------------------------------------+
//| InputParameters.mqh                                              |
//| Centralized, auditable input parameters.                         |
//| Every parameter here must have a documented rationale before     |
//| optimization (see Anti-Overfitting section of project brief).    |
//+------------------------------------------------------------------+
#ifndef __INPUTPARAMETERS_MQH__
#define __INPUTPARAMETERS_MQH__

//--- ===== Regime Filter =====
// Higher-timeframe trend/no-trend decision. Persistence checks exist
// specifically to avoid whipsaw entries on a single ADX spike.
input string           Sep0                = "===== Regime Filter =====";
input ENUM_TIMEFRAMES  InpRegimeTF         = PERIOD_H4;   // Timeframe for regime detection
input int              InpADX_Period       = 14;          // ADX period
input double           InpADX_Threshold    = 25.0;        // Minimum ADX to consider "trending"
input int              InpADX_PersistBars  = 3;           // ADX must stay above threshold this many closed bars
input int              InpEMA_TrendPeriod  = 50;          // EMA period defining trend direction
input int              InpEMA_SlopeBars    = 20;          // Bars back to measure EMA slope

//--- ===== Setup Detector =====
// Pullback-to-EMA logic, tolerance is ATR-based (adaptive to volatility)
// rather than a fixed pip value, per Phase 2 spec decision.
input string           Sep1                = "===== Setup Detector =====";
input ENUM_TIMEFRAMES  InpSetupTF          = PERIOD_H1;   // Timeframe for setup + confirmation
input int              InpEMA_PullbackPeriod = 20;        // EMA period defining pullback zone
input int              InpATR_Period       = 14;          // ATR period
input double           InpATR_ToleranceMult = 0.3;        // Pullback tolerance = ATR * this multiplier

//--- ===== Confirmation Engine =====
input string           Sep2                = "===== Confirmation Engine =====";
input int              InpRSI_Period       = 14;          // RSI period
input double           InpRSI_OversoldLvl  = 40.0;        // Minimum RSI for a valid buy rebound
input double           InpRSI_OverboughtLvl = 60.0;       // Maximum RSI for a valid sell rebound
input double           InpMinBodyRatio     = 0.5;         // Min |close-open|/(high-low) to count as rejection candle

//--- ===== Risk Management (Phase 5 - ACTIVE) =====
input string           Sep3                = "===== Risk Management =====";
input long             InpMagicNumber      = 20260910;    // Unique ID for this EA's trades (used to scope stats)
input double           InpRiskPercent      = 1.0;         // % of equity risked per trade
input double           InpMaxDailyLossPct  = 3.0;         // Max daily loss (% of day-start balance) before block
input double           InpMaxWeeklyLossPct = 6.0;         // Max weekly loss (% of week-start balance) before block
input double           InpMaxDrawdownPct   = 10.0;        // Max drawdown from peak equity before block
input int              InpMaxConsecLosses  = 5;           // Max consecutive losses (this EA only) before manual-review pause
input int              InpMaxOpenPositions = 1;           // Max concurrent positions (this EA, this symbol)
input double           InpMaxLotCap        = 1.0;         // Hard lot ceiling regardless of risk% calculation
input int              InpMaxSpreadPoints  = 350;         // Max allowed spread in points before blocking entries

//--- ===== Logging =====
input string           Sep4                = "===== Logging =====";
input bool             InpEnableFileLog    = true;        // Write logs to file in addition to Experts tab
input bool             InpVerboseLog       = true;        // Log non-signal diagnostic info too

//--- ===== SL/TP Calculation (Phase 6) =====
input string           Sep5                = "===== SL/TP Calculation =====";
input int              InpSwingLookbackBars = 10;         // Bars to scan for swing low/high (objective, deterministic)
input double           InpSL_BufferATRMult  = 0.3;        // Extra buffer beyond swing point, in ATR multiples
input double           InpMinRR             = 1.5;        // TP = SL distance x this multiple (see SLTPCalculator design note)

//--- ===== Trade Management (Phase 6) =====
input string           Sep6                = "===== Trade Management =====";
input double           InpBreakEvenRR       = 1.0;        // Move SL to breakeven once profit reaches this R multiple
input int              InpBreakEvenBufferPts = 20;        // Points beyond entry when moving to breakeven (covers spread/commission)
input double           InpTrailingActivateRR = 1.5;       // Start trailing once profit reaches this R multiple
input double           InpTrailingATRMult   = 1.5;        // Trailing distance = current ATR x this multiple

//--- ===== Execution (Phase 6) =====
input string           Sep7                = "===== Execution =====";
input int              InpMaxSlippagePoints = 30;         // Max acceptable slippage (order deviation), in points
input int              InpMaxRetries        = 3;          // Max retry attempts on requote/price-changed
input int              InpFridayCloseHour   = 21;          // Server-time hour on Friday after which NO new entries are taken

#endif // __INPUTPARAMETERS_MQH__
