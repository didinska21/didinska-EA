//+------------------------------------------------------------------+
//| InputParameters.mqh                                              |
//| Centralized, auditable input parameters.                         |
//| Every parameter here must have a documented rationale before     |
//| optimization (see Anti-Overfitting section of project brief).    |
//+------------------------------------------------------------------+
#ifndef __INPUTPARAMETERS_MQH__
#define __INPUTPARAMETERS_MQH__

//--- ===== Regime Filter =====
// Higher-timeframe trend/no-trend decision. Persistence checks exist
// specifically to avoid whipsaw entries on a single ADX spike.
input string           Sep0                = "===== Regime Filter =====";
input ENUM_TIMEFRAMES  InpRegimeTF         = PERIOD_H4;   // Timeframe for regime detection
input int              InpADX_Period       = 14;          // ADX period
input double           InpADX_Threshold    = 25.0;        // Minimum ADX to consider "trending"
input int              InpADX_PersistBars  = 3;           // ADX must stay above threshold this many closed bars
input int              InpEMA_TrendPeriod  = 50;          // EMA period defining trend direction
input int              InpEMA_SlopeBars    = 20;          // Bars back to measure EMA slope

//--- ===== Setup Detector =====
// Pullback-to-EMA logic, tolerance is ATR-based (adaptive to volatility)
// rather than a fixed pip value, per Phase 2 spec decision.
input string           Sep1                = "===== Setup Detector =====";
input ENUM_TIMEFRAMES  InpSetupTF          = PERIOD_H1;   // Timeframe for setup + confirmation
input int              InpEMA_PullbackPeriod = 20;        // EMA period defining pullback zone
input int              InpATR_Period       = 14;          // ATR period
input double           InpATR_ToleranceMult = 0.3;        // Pullback tolerance = ATR * this multiplier

//--- ===== Confirmation Engine =====
input string           Sep2                = "===== Confirmation Engine =====";
input int              InpRSI_Period       = 14;          // RSI period
input double           InpRSI_OversoldLvl  = 40.0;        // Minimum RSI for a valid buy rebound
input double           InpRSI_OverboughtLvl = 60.0;       // Maximum RSI for a valid sell rebound
input double           InpMinBodyRatio     = 0.5;         // Min |close-open|/(high-low) to count as rejection candle

//--- ===== Risk Management (placeholders — implemented in Phase 5) =====
input string           Sep3                = "===== Risk Management (Phase 5 - NOT YET ACTIVE) =====";
input double           InpRiskPercent      = 1.0;         // % of equity risked per trade
input double           InpMaxDailyLossPct  = 3.0;         // Max daily loss before emergency stop
input int              InpMaxConsecLosses  = 5;           // Max consecutive losses before manual-review pause

//--- ===== Logging =====
input string           Sep4                = "===== Logging =====";
input bool             InpEnableFileLog    = true;        // Write logs to file in addition to Experts tab
input bool             InpVerboseLog       = true;        // Log non-signal diagnostic info too

#endif // __INPUTPARAMETERS_MQH__
