//+------------------------------------------------------------------+
//| SetupDetector.mqh                                                |
//| Detects a pullback to the EMA20 zone using an ATR-scaled         |
//| tolerance (adaptive to volatility, per Phase 2 spec decision —   |
//| a fixed-pip tolerance was rejected as non-adaptive/subjective).  |
//|                                                                   |
//| DESIGN NOTE: both the EMA/ATR reads AND the reference price use  |
//| the last CLOSED bar (shift 1), never the live bid. Mixing a      |
//| closed-bar indicator value with a live tick price is a common    |
//| source of backtest-vs-live divergence; this keeps everything     |
//| anchored to the same bar.                                        |
//+------------------------------------------------------------------+
#ifndef __SETUPDETECTOR_MQH__
#define __SETUPDETECTOR_MQH__

#include "..\Include\Enums.mqh"
#include "..\Include\Logger.mqh"

class CSetupDetector
  {
private:
   int               m_ema_handle;
   int               m_atr_handle;
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   double            m_atr_tolerance_mult;
   CLogger          *m_logger;

public:
                     CSetupDetector()
     {
      m_ema_handle = INVALID_HANDLE;
      m_atr_handle = INVALID_HANDLE;
      m_logger     = NULL;
     }

   bool              Init(string symbol, ENUM_TIMEFRAMES tf, int ema_period, int atr_period,
                           double atr_tolerance_mult, CLogger *logger)
     {
      m_symbol             = symbol;
      m_tf                 = tf;
      m_atr_tolerance_mult = atr_tolerance_mult;
      m_logger             = logger;

      m_ema_handle = iMA(m_symbol, m_tf, ema_period, 0, MODE_EMA, PRICE_CLOSE);
      m_atr_handle = iATR(m_symbol, m_tf, atr_period);

      if(m_ema_handle == INVALID_HANDLE || m_atr_handle == INVALID_HANDLE)
        {
         if(m_logger != NULL)
            m_logger.Log("SetupDetector: failed to create indicator handles, error=" + IntegerToString(GetLastError()), LOG_ERROR);
         return false;
        }
      return true;
     }

   // Returns true if last closed bar's close is within ATR-scaled tolerance of EMA.
   bool              IsPullbackPresent(double &ema_value, double &atr_value)
     {
      double ema_buf[1], atr_buf[1];

      if(CopyBuffer(m_ema_handle, 0, 1, 1, ema_buf) < 1) return false;
      if(CopyBuffer(m_atr_handle, 0, 1, 1, atr_buf) < 1) return false;

      ema_value = ema_buf[0];
      atr_value = atr_buf[0];

      double price     = iClose(m_symbol, m_tf, 1); // last closed bar only
      double distance  = MathAbs(price - ema_value);
      double tolerance = atr_value * m_atr_tolerance_mult;

      return (distance <= tolerance);
     }

   void              Release()
     {
      if(m_ema_handle != INVALID_HANDLE) IndicatorRelease(m_ema_handle);
      if(m_atr_handle != INVALID_HANDLE) IndicatorRelease(m_atr_handle);
     }
  };

#endif // __SETUPDETECTOR_MQH__
