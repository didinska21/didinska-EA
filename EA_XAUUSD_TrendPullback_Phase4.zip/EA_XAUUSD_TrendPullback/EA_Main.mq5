//+------------------------------------------------------------------+
//| EA_Main.mq5                                                      |
//| EA_XAUUSD_TrendPullback                                          |
//|                                                                   |
//| PHASE 4 SCOPE (per project development plan):                   |
//|   - Regime Filter, Setup Detector, Confirmation Engine wired     |
//|     into an explicit state machine.                              |
//|   - Every decision is logged with full reasoning for audit.      |
//|   - Order execution is INTENTIONALLY NOT IMPLEMENTED yet.        |
//|     CRiskManager (Phase 5) and CEntryExecutor (Phase 6) do not   |
//|     exist in this build. This build only detects and logs        |
//|     signals — it will never open a position.                     |
//|                                                                   |
//| Do not attach this EA expecting live trades. It is a signal-     |
//| detection scaffold pending risk-management implementation and    |
//| audit, per the project's SURVIVAL-first phased protocol.         |
//+------------------------------------------------------------------+
#property copyright "Internal project build - Phase 4"
#property version   "0.40"

#include "Config\InputParameters.mqh"
#include "Include\Enums.mqh"
#include "Include\Logger.mqh"
#include "Include\RegimeFilter.mqh"
#include "Include\SetupDetector.mqh"
#include "Include\ConfirmationEngine.mqh"

CLogger              g_logger;
CRegimeFilter        g_regime;
CSetupDetector       g_setup;
CConfirmationEngine  g_confirm;

ENUM_EA_STATE        g_state;
datetime             g_last_bar_time;

//+------------------------------------------------------------------+
int OnInit()
  {
   g_state         = STATE_IDLE;
   g_last_bar_time = 0;

   string log_filename = StringFormat("EA_XAUUSD_TrendPullback_%s.log", _Symbol);
   g_logger.Init(log_filename, InpEnableFileLog);
   g_logger.Log("=== EA Initialized | PHASE 4 BUILD: signal-detection only, NO order execution ===", LOG_INFO);

   if(!g_regime.Init(_Symbol, InpRegimeTF, InpADX_Period, InpADX_Threshold,
                      InpADX_PersistBars, InpEMA_TrendPeriod, InpEMA_SlopeBars, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: RegimeFilter", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_setup.Init(_Symbol, InpSetupTF, InpEMA_PullbackPeriod, InpATR_Period,
                     InpATR_ToleranceMult, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: SetupDetector", LOG_ERROR);
      return INIT_FAILED;
     }

   if(!g_confirm.Init(_Symbol, InpSetupTF, InpRSI_Period, InpRSI_OversoldLvl,
                       InpRSI_OverboughtLvl, InpMinBodyRatio, GetPointer(g_logger)))
     {
      g_logger.Log("OnInit failed: ConfirmationEngine", LOG_ERROR);
      return INIT_FAILED;
     }

   g_logger.Log("All Phase 4 modules initialized successfully.", LOG_INFO);
   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_logger.Log("EA Deinitialized. Reason code=" + IntegerToString(reason), LOG_INFO);
   g_regime.Release();
   g_setup.Release();
   g_confirm.Release();
   g_logger.Deinit();
  }

//+------------------------------------------------------------------+
// Evaluates once per closed bar on the setup timeframe (H1 default).
// Prevents re-evaluating the same signal multiple times per bar and
// keeps every decision anchored to closed-bar data (see module notes).
bool IsNewBar()
  {
   datetime current_bar_time = iTime(_Symbol, InpSetupTF, 0);
   if(current_bar_time != g_last_bar_time)
     {
      g_last_bar_time = current_bar_time;
      return true;
     }
   return false;
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   if(!IsNewBar())
      return;

   RunStateMachine();
  }

//+------------------------------------------------------------------+
void RunStateMachine()
  {
   ENUM_TREND_DIRECTION direction;

//--- Step 1: Regime Filter
   if(!g_regime.IsTrendValid(direction))
     {
      if(g_state != STATE_IDLE && InpVerboseLog)
         g_logger.Log("Regime invalid -> back to IDLE", LOG_INFO);
      g_state = STATE_IDLE;
      return;
     }

   g_state = STATE_SCANNING_FOR_SETUP;

//--- Step 2: Setup Detector
   double ema_value, atr_value;
   if(!g_setup.IsPullbackPresent(ema_value, atr_value))
      return; // trending, but no pullback into the zone yet

   g_state = STATE_WAITING_CONFIRMATION;
   g_logger.Log(StringFormat("Setup detected | direction=%s EMA=%.2f ATR=%.2f",
                EnumToString(direction), ema_value, atr_value), LOG_INFO);

//--- Step 3: Confirmation Engine
   if(!g_confirm.IsConfirmed(direction))
      return; // pullback present, confirmation not yet met

   g_state = STATE_ENTRY_TRIGGERED;
   g_logger.Log(StringFormat("*** SIGNAL CONFIRMED *** direction=%s EMA=%.2f ATR=%.2f | execution NOT implemented (Phase 5/6 pending)",
                EnumToString(direction), ema_value, atr_value), LOG_TRADE);

   //-----------------------------------------------------------------
   // INTENTIONALLY NOT CALLED:
   //   if (!g_riskManager.IsTradingAllowed()) return;
   //   g_entryExecutor.ExecuteEntry(direction, ema_value, atr_value);
   //
   // CRiskManager and CEntryExecutor do not exist in this build.
   // Wiring order execution before risk management is implemented
   // and audited would violate the project's SURVIVAL-first principle.
   //-----------------------------------------------------------------

   g_state = STATE_IDLE; // reset for next bar's independent evaluation
  }
//+------------------------------------------------------------------+
